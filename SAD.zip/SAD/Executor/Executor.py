import os
import re
import json
import numpy as np
import random
from collections import defaultdict, Counter
from scipy.optimize import linear_sum_assignment
from Preprocessor.ClassDependencyGraph import BLIST
from Executor.utils.MethodParser import (
    MethodParser, 
    WHITELIST,
    LSH
)
random.seed(1024)

class Executor:
    def __init__(self, i, APKnode, TPLnode, CDGs, logger, verbose=False):
        self.APKnode = APKnode
        self.TPLnode = TPLnode
        self.CDGs = CDGs
        self.logger = logger
        self.verbose = verbose
        
        with open("config/HyperParams.json") as f:
            hyperparams = json.load(f)
        self.threshold_ssc = hyperparams["node_match_threshold"]
        self.ivkstate_threshold = hyperparams['ivkstate_threshold']
        self.high_confidence = hyperparams['high_confidence']
        self.mtd_threshold = hyperparams["ivkstate_threshold"]
    
    def __call__(self):
        if self.TPLnode.clzName[1:-1].split('/')[-1] == "BuildConfig":
            # 没什么用，可以忽略
            return 0.0, set()
        else:
            similarity, fldtypes = self.__SSC(self.APKnode)
        self.logger.debug(f"[·] Summary Similarity: {similarity}")
                
        return similarity, fldtypes
    
    def generateInvocationChain(self, mtds):
        clinit_mtd = None 
        for mtd in mtds:
            if "<clinit>" in mtd:
                clinit_mtd = mtd
                
        init_mtds = [mtd for mtd in mtds if "<init>" in mtd and "static" not in mtd and "abstract" not in mtd]
        non_init_mtds = [mtd for mtd in mtds if "<init>" not in mtd and "<clinit>" not in mtd and "static" not in mtd and "abstract" not in mtd]
        static_mtds = [mtd for mtd in mtds if "<init>" not in mtd and "<clinit>" not in mtd and "static" in mtd and "abstract" not in mtd]
        
        invocationChains = []
        N = len(mtds)
        if N > 20:
            N = N // 2
        for _ in range(N):
            if clinit_mtd:
                chain = [clinit_mtd]
            else:
                chain = []

            if len(static_mtds):
                chain.append(random.choice(static_mtds))

            if len(init_mtds):
                chain.append(random.choice(init_mtds))
            
            if len(non_init_mtds):
                tmp_set = list(non_init_mtds)
                for _ in range(random.randint(1, len(tmp_set))):
                    choosed_mtd = random.choice(tmp_set)
                    chain.append(choosed_mtd)
                    tmp_set.remove(choosed_mtd)
                invocationChains.append(chain)
        
        return invocationChains

    def merge_dict(self, d1, d2):
        import copy
        result = copy.deepcopy(dict(d1))
        for key in d2:
            if key not in result:
                result[key] = d2[key]
            else:
                for inkey in d2[key]:
                    if inkey not in result[key]:
                        result[key][inkey] = d2[key][inkey]
                    else:
                        result[key][inkey] += d2[key][inkey]
        return result
    
    def get_opcodes(self, ops):
        new_ops = list()
        for op in ops:
            if "move" in op or "switch" in op or "goto" in op or\
                "cmp" in op or "if" in op or "throw" in op:
                continue
            if op.find('/'):
                new_ops.append(op.split("/")[0])
            else:
                new_ops.append(op)
        return new_ops
    
    def check_state(self, all_fields_tpl, all_fields_apk, mtdtplCodes, mtdapkCodes):
        apkmp = MethodParser(all_fields_apk, mtdapkCodes, WHITELIST)
        tplmp = MethodParser(all_fields_tpl, mtdtplCodes, WHITELIST)
        return tplmp(), apkmp()
    
    def cosine_similarity(self, vec1, vec2):
        vec1 = np.array(vec1)
        vec2 = np.array(vec2)
        dot_product = np.dot(vec1, vec2)
        norm_vec1 = np.linalg.norm(vec1)
        norm_vec2 = np.linalg.norm(vec2)
        if norm_vec1 == 0 or norm_vec2 == 0:
            return 0.0
        else:
            return dot_product / (norm_vec1 * norm_vec2)
        
    def Hungarian(self, data1, data2, match_result):
        def create_similarity_matrix(A, B, match_result):
            num_A = len(A)
            num_B = len(B)
            
            valid_rows_cols = []

            similarity_matrix = np.zeros((num_A, num_B))
            
            for a_idx, b_indices in match_result.items():
                if A[a_idx] is None:
                    continue
                for b_idx in b_indices:
                    if B[b_idx] is None:
                        continue
                    hash_similarity = self.cosine_similarity(A[a_idx], B[b_idx])
                    if hash_similarity >= self.mtd_threshold:
                        similarity_matrix[list(A.keys()).index(a_idx), list(B.keys()).index(b_idx)] = hash_similarity
                        valid_rows_cols.append((list(A.keys()).index(a_idx), list(B.keys()).index(b_idx)))
            
            return similarity_matrix, valid_rows_cols
        
        def maximize_matching(similarity_matrix):
            row_ind, col_ind = linear_sum_assignment(-similarity_matrix)
            return row_ind, col_ind  
        
        similarity_matrix, valid_rows_cols = create_similarity_matrix(data1, data2, match_result)
        
        if np.all(similarity_matrix < self.mtd_threshold):
            return {}

        row_ind, col_ind = maximize_matching(similarity_matrix)
        refined_matches = {list(data1.keys())[row]: list(data2.keys())[col] for row, col in zip(row_ind, col_ind) if (row, col) in valid_rows_cols}
        return refined_matches
    

    def __SSC(self, apknode):
        self.logger.debug(f"[+] SSC", verbose=self.verbose)

        field_usage_apk = apknode.fields_usage
        field_usage_tpl = self.TPLnode.fields_usage

        use_field_mtd_apk = set()
        use_field_mtd_tpl = set()
        for mtd in field_usage_tpl:
            if len(field_usage_tpl[mtd]):
                for key in field_usage_tpl[mtd]:
                    if len(field_usage_tpl[mtd][key]):
                        use_field_mtd_tpl.add(mtd)
                        break
        for mtd in field_usage_apk:
            if len(field_usage_apk[mtd]):
                for key in field_usage_apk[mtd]:
                    if len(field_usage_apk[mtd][key]):
                        use_field_mtd_apk.add(mtd)
                        break

        clinit_apk_use_fld = None
        clinit_tpl_use_fld = None
        used_fields_apk = set()
        used_fields_tpl = set()
        for mtd in field_usage_apk:
            for op in field_usage_apk[mtd]:
                if clinit_apk_use_fld is None and "<clinit>" in mtd:
                    clinit_apk_use_fld = "<clinit>"
                for fld in field_usage_apk[mtd][op]:
                    used_fields_apk.add(fld)
                
        for mtd in field_usage_tpl:
            for op in field_usage_tpl[mtd]:
                if clinit_tpl_use_fld is None and "<clinit>" in mtd:
                    clinit_tpl_use_fld = "<clinit>"
                for fld in field_usage_tpl[mtd][op]:
                    used_fields_tpl.add(fld)

        apkfields = apknode.in_class_src_fields 
        tplfields = self.TPLnode.in_class_src_fields 

        tplmtdsMapping = defaultdict(list)
        mtdsMapping = {}
        
        tplmtdsSigs = self.TPLnode.methods_infos['methodSignatures']
        apkmtdsSigs = apknode.methods_infos['methodSignatures']

        tplslice = self.TPLnode.methods_infos['methodSlice']
        apkslice = apknode.methods_infos['methodSlice']
        
        if len(tplmtdsSigs) == 0:
            return .0, set()
            
        for tplmtd in tplmtdsSigs:
            for apkmtd in apkmtdsSigs:
                if tplmtdsSigs[tplmtd] == apkmtdsSigs[apkmtd]:
                    tplmtdsMapping[tplmtd].append(apkmtd)

        methods_have_opcodes_tpl = 0
        total_tpl_ops = 0
        matched_tpl_ops = 0
        
        hasher = LSH()
        tplmtdSumHash = {}
        apkmtdSumHash = {}
        for tplmtd in tplmtdsSigs:
            tplmtdSumHash[tplmtd] = hasher.compute_minhash(sorted(tplslice[tplmtd])) if len(tplslice[tplmtd]) else None
        for apkmtd in apkmtdsSigs:
            apkmtdSumHash[apkmtd] = hasher.compute_minhash(sorted(apkslice[apkmtd])) if len(apkslice[apkmtd]) else None

        step1mtdsMapping = self.Hungarian(tplmtdSumHash, apkmtdSumHash, tplmtdsMapping)

        all_fields_apk = []
        all_fields_tpl = []
        matched_apk_mtd = []

        for tplmtd in tplmtdsMapping:
            if tplmtd in step1mtdsMapping:
                matched_tpl_ops += len(self.TPLnode.methods_infos['methodOpcodes'][tplmtd])
                mtdsMapping[tplmtd] = step1mtdsMapping[tplmtd]
                matched_apk_mtd.append(step1mtdsMapping[tplmtd])
                continue

            if tplmtdSumHash[tplmtd] is not None:
                continue

            total_tpl_ops += len(self.get_opcodes(self.TPLnode.methods_infos['methodOpcodes'][tplmtd]))
            if len(tplmtdsMapping[tplmtd]):
                tplmtd_opcodes = Counter(self.get_opcodes(self.TPLnode.methods_infos['methodOpcodes'][tplmtd]))
                opcode_match_scores = {}
                if len(tplmtd_opcodes) and sum(tplmtd_opcodes.values()) >= 3:
                    methods_have_opcodes_tpl += 1

                for apkmtd in tplmtdsMapping[tplmtd]:
                    apkmtd_opcode = Counter(self.get_opcodes(apknode.methods_infos['methodOpcodes'][apkmtd]))
                    if len(tplmtd_opcodes):
                        score = sum((apkmtd_opcode & tplmtd_opcodes).values())/max(sum(tplmtd_opcodes.values()),sum(apkmtd_opcode.values()))
                    else:
                        score = int(len(apkmtd_opcode) == len(tplmtd_opcodes))
                    if score > self.mtd_threshold:
                        opcode_match_scores[apkmtd] = score

                if len(opcode_match_scores):
                    def same_mtd_name(mtdname):
                        if "<init>" in mtdname:
                            return "<init>"
                        if "<clinit>" in mtdname:
                            return "<clinit>"
                        return "mtd"
                    
                    for candidate, score in sorted(opcode_match_scores.items(), key=lambda x: x[1], reverse=True):
                        if same_mtd_name(candidate) != same_mtd_name(tplmtd):
                            continue

                        if candidate in matched_apk_mtd:
                            continue

                        if tplmtd in field_usage_tpl and candidate in field_usage_apk:

                            tpl_keys = set()
                            if "read" in field_usage_tpl[tplmtd]:
                                for fld in field_usage_tpl[tplmtd]["read"]:
                                    if fld in tplfields:
                                        tpl_keys.add(fld)
                            if "write" in field_usage_tpl[tplmtd]:
                                for fld in field_usage_tpl[tplmtd]["write"]:
                                    if fld in tplfields:
                                        tpl_keys.add(fld)
                                    
                            apk_keys = set()
                            if "read" in field_usage_apk[candidate]:
                                for fld in field_usage_apk[candidate]["read"]:
                                    if fld in apkfields:
                                        apk_keys.add(fld)
                            if "write" in field_usage_apk[candidate]:
                                for fld in field_usage_apk[candidate]["write"]:
                                    if fld in apkfields:
                                        apk_keys.add(fld)

                            if len(apk_keys) == len(tpl_keys):
                                mtdsMapping[tplmtd] = candidate
                                matched_apk_mtd.append(candidate)
                                all_fields_apk.extend(list(apk_keys))
                                all_fields_tpl.extend(list(tpl_keys))
                                matched_tpl_ops += len(self.get_opcodes(self.TPLnode.methods_infos['methodOpcodes'][tplmtd]))
                                break

                        elif (tplmtd not in field_usage_tpl and candidate not in field_usage_apk):
                            mtdsMapping[tplmtd] = candidate
                            matched_apk_mtd.append(candidate)
                            matched_tpl_ops += len(self.get_opcodes(self.TPLnode.methods_infos['methodOpcodes'][tplmtd]))
                            break
                            
        all_fields_tpl = set(all_fields_tpl)
        all_fields_apk = set(all_fields_apk)

        if methods_have_opcodes_tpl == 0:
            if len(tplmtdsSigs) - len(mtdsMapping) < 2 and \
                (abs(len(apknode.members) - len(self.TPLnode.members)) < 2 and \
                Counter(memb for memb in apknode.members if '[FIELD]' in memb) == Counter(memb for memb in self.TPLnode.members if '[FIELD]' in memb)):
                penalty = len(set(tplmtdsSigs.keys())-set(mtdsMapping.keys()))/len(tplmtdsSigs)
                if len(apkmtdsSigs):
                    penalty = (penalty+len(set(apkmtdsSigs.keys())-set(mtdsMapping.values()))/len(apkmtdsSigs))/2
                return 1.0-penalty, set([self.TPLnode.fields_type[fldname] for fldname in all_fields_tpl])
            
        elif matched_tpl_ops/total_tpl_ops < self.mtd_threshold:
            return 0.0, set()

        def isExtClass(clzname):
            cnt = 0
            while clzname[0] == '[':
                clzname = clzname[1:]
                cnt += 1
            
            newname = None
            if clzname in ['B', 'C', 'D', 'F', 'I', 'J', 'S', 'Z', 'V']:
                newname = clzname
            else:
                for item in BLIST:
                    if clzname.startswith(item):
                        newname = clzname
                        break
            if newname is None:
                newname = "selfdefined"
            
            return '['*cnt + newname
        
        if len(set(tplfields)-all_fields_tpl):
            remain_tplfld = set(item for item in (set(tplfields)-all_fields_tpl) if item in tplfields)
            remain_apkfld = set(item for item in (set(apkfields)-all_fields_apk) if item in apkfields)

            tplunmatched_flds = Counter([isExtClass(self.TPLnode.fields_type[fld]) for fld in remain_tplfld])
            apkunmatched_flds = Counter([isExtClass(apknode.fields_type[fld]) for fld in remain_apkfld])
            if len(remain_tplfld) != len(remain_apkfld) and tplunmatched_flds != apkunmatched_flds:
                if sum(tplunmatched_flds.values()):
                    return sum((tplunmatched_flds&apkunmatched_flds).values())/sum(tplunmatched_flds.values()) - sum((apkunmatched_flds-tplunmatched_flds).values())/sum(apkunmatched_flds.values()) if sum(apkunmatched_flds.values()) else 0, set([self.TPLnode.fields_type[fldname] for fldname in all_fields_tpl])
                else:
                    return 1/sum(apkunmatched_flds.values()), set([self.TPLnode.fields_type[fldname] for fldname in all_fields_tpl])
        
        invocationChains = self.generateInvocationChain(list(set(mtdsMapping.keys())&use_field_mtd_tpl))
        
        results = []
        if len(all_fields_tpl) != 0:
            for invocationChain in invocationChains:
                state_apk = {}
                state_tpl = {}
                apk_ivk_history = set()
                tpl_ivk_history = set()
                for mtdtpl in invocationChain:
                    apk_ivk_history.add(mtdsMapping[mtdtpl])
                    tpl_ivk_history.add(mtdtpl)
                    
                    mtdtplCodes = self.TPLnode.methods_infos['methodCodes'][mtdtpl]
                    mtdapkCodes = apknode.methods_infos['methodCodes'][mtdsMapping[mtdtpl]]
                    if mtdtplCodes is None:
                        break
                    if mtdapkCodes is None:
                        break
                    
                    restpl, resapk = self.check_state(all_fields_tpl, all_fields_apk, mtdtplCodes, mtdapkCodes)
                    if resapk is not None and restpl is not None:
                        state_apk = self.merge_dict(state_apk, resapk)
                        state_tpl = self.merge_dict(state_tpl, restpl)
                    
                    
                    apkinvoks = apknode.methods_infos['self-invocations'][mtdsMapping[mtdtpl]]
                    for mtd in self.TPLnode.methods_infos['self-invocations'][mtdtpl]:
                        if mtd in mtdsMapping and mtdsMapping[mtd] in apkinvoks and\
                            mtd not in tpl_ivk_history and mtdsMapping[mtd] not in apk_ivk_history and\
                            mtd not in invocationChain:

                            apk_ivk_history.add(mtdsMapping[mtd])
                            tpl_ivk_history.add(mtd)
                            
                            mtdtplCodes = self.TPLnode.methods_infos['methodCodes'][mtd]
                            mtdapkCodes = apknode.methods_infos['methodCodes'][mtdsMapping[mtd]]
                            restpl, resapk = self.check_state(all_fields_tpl, all_fields_apk, mtdtplCodes, mtdapkCodes)
                            if resapk is not None and restpl is not None:
                                state_apk = self.merge_dict(state_apk, resapk)
                                state_tpl = self.merge_dict(state_tpl, restpl)
                
                if len(state_tpl):
                    data1=MethodParser.get_output_hash(state_apk)
                    data2=MethodParser.get_output_hash(state_tpl)

                    candidates = []
                    for i in data1:
                        for j in data2:
                            sim = self.cosine_similarity(data1[i], data2[j])
                            if sim > self.ivkstate_threshold:  
                                candidates.append((i, j, sim))

                    candidates = sorted(candidates, key=lambda x: x[2], reverse=True)

                    matched1 = set()  
                    matched2 = set()  
                    matches = []      
                    for i, j, sim in candidates:
                        if i not in matched1 and j not in matched2:
                            matches.append((i, j))  
                            matched1.add(i)         
                            matched2.add(j)         

                    if len(matches)/len(data2) > self.ivkstate_threshold:
                        results.append(len(matches)/len(data2))
                               
        self.logger.debug(f"Mapped Methods num: {len(mtdsMapping)}, Invocation num: {sum([len(item) for item in invocationChains])}, Scores: {results}", verbose=self.verbose)

        if len(results):
            result_sc = sum(results)/len(results)
        else:
            result_sc = 0

        result_usc = len(mtdsMapping)/len(tplmtdsSigs)
        if len(apkmtdsSigs):
            result_usc = (result_usc + len(mtdsMapping)/len(apkmtdsSigs))/2

        return max(result_sc, result_usc), set([self.TPLnode.fields_type[fldname] for fldname in all_fields_tpl])
    
