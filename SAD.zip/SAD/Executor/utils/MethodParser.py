import re
import yaml
import javalang
from javalang.tree import (
    MethodDeclaration,
    ConstructorDeclaration,
    MemberReference,
    MethodInvocation,
    Assignment,
    This,
    Literal,
    IfStatement,
    WhileStatement,
    DoStatement,
    ForStatement,
    BlockStatement,
    TryStatement,
    SwitchStatement,
    SwitchStatementCase,
    BinaryOperation,
    ReturnStatement,
    Cast,
    BasicType,
    ReferenceType
)
from collections import defaultdict

WHITELIST = [
    "android.os.",
    "android.text.",
    "android.util.",
    "android.webkit.",
    "android.net.",
    "android.database.",
    "android.print.",
    "android.transition.",
    "android.hardware.",
    "android.provider.",
    "android.accessibilityservice.",
    "android.speech.",
    "android.location.",
    "android.preference.",
    "android.content.",
    "android.view.",
    
    "java.lang.",
    "java.util.",
    "java.io.",
    "java.text.",
    "java.nio.",
    "java.math.",
]

    
class LSH:
    def __init__(self, num_hashes=200):
        self.num_hashes = num_hashes

    def compute_minhash(self, tokens):
        # Create a set of unique tokens
        unique_tokens = set([''.join(map(str, token)) for token in tokens])
        # Create a binary vector for each token
        vector = [0 for _ in range(self.num_hashes)]
        # print(unique_tokens)
        for i in range(self.num_hashes):
            # Hash each token to a random value
            hash_values = [hash(token + str(i)) % (self.num_hashes) for token in unique_tokens]
            # Set the corresponding position in the vector
            vector[i] = min(hash_values)  # Using min-hash for this example

        return vector


def remove_cast(java_code):
    matches = re.findall(r'=\s*\(\s*[a-zA-Z0-9._$]+\s*\)', java_code)
    while len(matches):
        for match in matches:
            java_code = java_code.split(match)[0] + "=" + java_code.split(match)[1]
        matches = re.findall(r'=\s*\(\s*[a-zA-Z0-9._$]+\s*\)', java_code)
    return java_code

def remove_brackets(java_code):
    result = java_code.split(' =' )[0] + ' = '
    rhs = java_code.split(' = ')[-1].strip(';\n')
    while rhs.strip()[0] == '(' and rhs.strip()[-1] == ')':

        stack = []
        parentheses_map = {')': '(', '}': '{', ']': '['}
        Tag = True
        for char in rhs.strip()[1:-1]:
            if char in parentheses_map.values():
                stack.append(char)
            elif char in parentheses_map:
                if stack and stack[-1] == parentheses_map[char]:
                    stack.pop()
                else:
                    Tag = False
                    break
        if Tag and len(stack) == 0:
            rhs = rhs.strip()[1:-1]
        else:
            break
    return result + rhs + ';\n'

def fix_missing_parentheses(java_code):
    if 'new' in java_code:
        pattern = r'(\bnew\s+[a-zA-Z0-9_.\$]+)\s*;'
        fixed_code = re.sub(pattern, r'\1();', java_code)
        return fixed_code
    return java_code

def find_void_declaration(code_line):
    pattern = r'\bvoid\s+\w+\b.*;'
    match = re.search(pattern, code_line)
    return code_line.replace('void', 'thisPtr')

def fix_java_catch_block(code_line):
    pattern = r'catch\s*\(\s*(?:int|long|short|byte|float|double|boolean|char|[A-Za-z0-9\.\$_]+)(\[\])*\s+\w+\s*\)'
    replacement = r'catch (Exception e)'
    
    fixed_line = re.sub(pattern, replacement, code_line)

    return fixed_line

def fix_array_initializations(code_line):
    pattern = r'^(\s*)(\w+)\s*=\s*\{.*\};\s*$'
    match = re.search(pattern, code_line)
    if match:
        indent, var_name = match.groups()
        fixed_line = f"{indent}Object[] {var_name} ={code_line.split('=')[-1]}\n"
        return fixed_line
    
    return code_line

def fix_method_declarations(code_line):
    pattern = r'[^\sa-zA-Z0-9)\._\$]+\s*(int|long|short|byte|float|double|boolean|char|[A-Za-z0-9\.\$_]+)\s+([a-zA-Z0-9_\$]+)\s*[^\sa-zA-Z0-9()]*.*;'
    match = re.search(pattern, code_line.replace('new ', " "))
    while match:
        code_line = code_line.replace(f"{match.groups()[0]} {match.groups()[1]}", f"({match.groups()[0]}) {match.groups()[1]}")
        match = re.search(pattern, code_line.replace('new ', " "))
    return code_line

def check_and_fix_brackets(code_line):
    stack = []
    Tag = True
    for ch in code_line:
        if ch == '(':
            stack.append(ch)
        elif ch == ')':
            if len(stack) and stack[-1] == '(':
                stack.pop()
            else:
                Tag = False
                break
    
    if Tag and len(stack) == 0:
        return code_line
    
    stack = []
    corrected_line = []
    
    for char in code_line.strip(';'):
        if char == '(':
            stack.append(char)  
            corrected_line.append(char)
        elif char == ')':
            if stack and stack[-1] == '(':
                stack.pop()  
                corrected_line.append(char)
            else:
                corrected_line.append('')  
        else:
            corrected_line.append(char)

    if len(stack):
        while stack:
            corrected_line.append(')')  
            stack.pop()

    return ''.join(corrected_line) + ';'

def refine_code(line):
    if ' = ' in line:
        # line = check_and_fix_brackets(line)
        line = find_void_declaration(line)
        line = fix_missing_parentheses(remove_brackets(remove_cast(line)))
        line = fix_array_initializations(line)
        # line = line.split('=')[0] + ' = ' + fix_method_declarations(line.split(' = ')[-1])
        if "super" in line:
            line = line.replace('super)', 'super())').replace('super,', 'super(),').replace('super;', 'super();')
    else:
        # line = check_and_fix_brackets(line)
        line = fix_java_catch_block(find_void_declaration(line))
        # line = fix_method_declarations(line)
        line = line + '\n'
        if "super" in line:
            line = line.replace('super)', 'super())').replace('super,', 'super(),').replace('super;', 'super();')
    return line

class MethodParser:

    hasher = LSH()
    
    def __init__(self, fieldsList, mtdCode, classWhitelist):
        try:
            self.fieldsList = fieldsList
            self.mtdCode = ""
            for line in mtdCode.replace('synthetic', '').replace('bridge', '').replace("varargs", '').replace('declared_synchronized', '').split('\n'):        
                self.mtdCode += refine_code(line)
         
            self.classWhitelist = classWhitelist
            self.wrapCode = "public class WRAPPERCLASS {\n" + self.mtdCode + "\n}\n"
            tree = javalang.parse.parse(self.wrapCode)
            self.parse_succ = True
        except Exception as e:
            self.parse_succ = False

        self.field_operations = defaultdict(lambda: {"Assignment": [], "Invocation": [], "Initialized": []})

        if self.parse_succ:
            for _, node in tree.filter(javalang.tree.TypeDeclaration):
                if hasattr(node, 'body'):
                    for body_node in node.body:
                        if isinstance(body_node, (ConstructorDeclaration, MethodDeclaration)):
                            method_params = {}
                            for param in body_node.parameters:
                                if isinstance(param.type, BasicType):
                                    method_params[param.name] = param.type.name
                                elif isinstance(param.type, ReferenceType):
                                    clzname = self.get_classname(param.type)
                                    ADDED = False
                                    for wh in classWhitelist:
                                        if clzname.startswith(wh):
                                            method_params[param.name] = clzname
                                            ADDED = True
                                            break
                                    if not ADDED:
                                        method_params[param.name] = "SelfDefinedClass"
                            try:
                                self.parse_java_method(method_params, body_node.body, self.classWhitelist)
                            except Exception as e:
                                print(f"Error in parse_java_method: \n{self.mtdCode}")
                                self.parse_succ = False
                                return
                            
                        
    def __call__(self):
        if self.parse_succ:
            return self.field_operations
        else:
            return None

    @staticmethod
    def get_yaml_output(inputs):
        output = ""
        for field in inputs:
            ops = inputs[field]
            if any(ops.values()):
                output += f"- field_name: {field}\n"
                if ops["Initialized"]:
                    for item in ops["Initialized"]:
                        output += f"  Initialization:\n  - {item['type']}\n"
                if ops["Assignment"]:
                    for item in ops["Assignment"]:
                        output += f"  Assignment:\n  - arguments: {item['parameters']}\n"
                if ops["Invocation"]:
                    for item in ops["Invocation"]:
                        output += f"  Invocation:\n  - arguments: {item['parameters']}\n"
        return output

    @staticmethod
    def get_output_hash(inputs):
        output = {}
        for field in inputs:
            ops = inputs[field]
            field_opts = list()
            if any(ops.values()):
                if ops["Initialized"]:
                    for item in ops["Initialized"]:
                        field_opts.append(f"Initialization: {','.join(item['type'])}")
                if ops["Assignment"]:
                    for item in ops["Assignment"]:
                        field_opts.append(f"Assignment: {','.join(item['parameters'])}")
                if ops["Invocation"]:
                    for item in ops["Invocation"]:
                        field_opts.append(f"Invocation: {','.join(item['parameters'])}")
                field_hash = MethodParser.hasher.compute_minhash(sorted(field_opts))
                output[field] = field_hash
        return output
    
    def get_classname(self, obj):
        return obj.name + ('.'+self.get_classname(obj.sub_type) if obj.sub_type else "")

    def in_whitelist(self, clzname, whitelist):
        for wh in whitelist:
            if clzname.startswith(wh):
                return True
        return False

    def extract_elements(self, expression, method_params):
        # print(expression)
        extracted = []
        if isinstance(expression, list):
            for expr in expression:
                extracted.extend(self.extract_elements(expr,  method_params))
                
        elif isinstance(expression, MemberReference):
            if expression.member in self.fieldsList:
                extracted.append('[Field] '+expression.member)
            elif expression.member in method_params:
                extracted.append(f'[Parameter{list(method_params.keys()).index(expression.member)}]'+'-'+method_params[expression.member])
                
        elif isinstance(expression, Literal):
            extracted.append('[Constant] '+expression.value)
            
        elif isinstance(expression, MethodInvocation):
            if expression.qualifier:
                if expression.qualifier in self.fieldsList:
                    extracted.append('[Field] '+expression.qualifier)
                    
                elif expression.qualifier in method_params:
                    extracted.append(f'[Parameter{list(method_params.keys()).index(expression.qualifier)}]'+'-'+method_params[expression.qualifier])
                    
            if expression.member in self.fieldsList:
                extracted.append('[Field] '+expression.member)
            elif expression.member in method_params:
                extracted.append(f'[Parameter{list(method_params.keys()).index(expression.member)}]'+'-'+method_params[expression.member])
                
            for arg in expression.arguments:
                extracted.extend(self.extract_elements(arg,  method_params))
            
                
        elif isinstance(expression, Assignment):
            extracted.extend(self.extract_elements(expression.value, method_params))
            
        elif isinstance(expression, This):
            if expression.selectors:
                extracted.extend(self.extract_elements(expression.selectors, method_params))
                
        elif isinstance(expression, BinaryOperation):
            extracted.extend(self.extract_elements(expression.operandl, method_params))
            extracted.extend(self.extract_elements(expression.operandr, method_params))
        
        elif isinstance(expression, Cast):
            extracted.extend(self.extract_elements(expression.expression, method_params))


        return extracted


    def parse_java_method(self, method_params, statements, clzwhitelist):
        for statement in statements:
            # print(statement)
            if isinstance(statement, javalang.tree.StatementExpression):
                expression = statement.expression

                if isinstance(expression, Assignment):
                    lhs = expression.expressionl
                    rhs = expression.value
                    lhs_field = None

                    if isinstance(lhs, MemberReference):
                        lhs_field = lhs.member

                    if isinstance(lhs, This) and len(lhs.selectors) and isinstance(lhs.selectors[0], MemberReference):
                        lhs_field = lhs.selectors[0].member

                    if lhs_field and lhs_field in self.fieldsList:
                        
                        if isinstance(rhs, javalang.tree.ArrayCreator):
                            clzname = self.get_classname(rhs.type)
                            if self.in_whitelist(clzname, clzwhitelist):
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize Array [{clzname}]"})
                            else:
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize Array [SelfDefinedClass]"})
                            continue
                            
                        elif isinstance(rhs, javalang.tree.ClassCreator):
                            clzname = self.get_classname(rhs.type)
                            if self.in_whitelist(clzname, clzwhitelist):
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize Object [{clzname}]"})
                            else:
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize Object [SelfDefinedClass]"})
                            continue
                                
                        elif isinstance(rhs, javalang.tree.InnerClassCreator):
                            clzname = self.get_classname(rhs.type)
                            if self.in_whitelist(clzname, clzwhitelist):
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize InnerObject [{clzname}]"})
                            else:
                                self.field_operations[lhs_field]["Initialized"].append({"type": f"Initialize InnerObject [SelfDefinedClass]"})
                            continue
                        
                        else:
                            tmp = self.extract_elements(rhs, method_params)
                            self.field_operations[lhs_field]["Assignment"].append({"parameters": tmp})

                elif isinstance(expression, This):
                    field_name = None
                    for selector in expression.selectors:
                        if isinstance(selector, MemberReference):
                            field_name = selector.member
                        if isinstance(selector, MethodInvocation):
                            if field_name is not None and field_name in self.fieldsList:
                                args = self.extract_elements(selector.arguments, method_params)
                                self.field_operations[field_name]["Invocation"].append({"parameters": args})
                            elif selector.member in self.fieldsList:
                                args = self.extract_elements(selector.arguments, method_params)
                                self.field_operations[field_name]["Invocation"].append({"parameters": args})
                                
                    
            elif isinstance(statement, IfStatement):
                self.parse_java_method(method_params, statement.then_statement.statements if isinstance(statement.then_statement, BlockStatement) else [statement.then_statement], clzwhitelist)
                if statement.else_statement:
                    self.parse_java_method(method_params, statement.else_statement.statements if isinstance(statement.else_statement, BlockStatement) else [statement.else_statement], clzwhitelist)

            elif isinstance(statement, (WhileStatement, DoStatement, ForStatement, BlockStatement)):
                if isinstance(statement.body, javalang.tree.StatementExpression):
                    self.parse_java_method(method_params, [statement.body], clzwhitelist)
                else:
                    self.parse_java_method(method_params, statement.body.statements, clzwhitelist)

            elif isinstance(statement, TryStatement):
                self.parse_java_method(method_params, statement.block, clzwhitelist)
                for catch_clause in statement.catches:
                    self.parse_java_method(method_params, catch_clause.block, clzwhitelist)
                if statement.finally_block:
                    self.parse_java_method(method_params, statement.finally_block, clzwhitelist)

            elif isinstance(statement, SwitchStatement):
                for case in statement.cases:
                    self.parse_java_method(method_params, case.statements, clzwhitelist)
                    
            elif isinstance(statement, ReturnStatement):
                self.extract_elements(statement.expression, method_params)

            if hasattr(statement, 'statements') and isinstance(statement.statements, list):
                self.parse_java_method(method_params, statement.statements, clzwhitelist)
                