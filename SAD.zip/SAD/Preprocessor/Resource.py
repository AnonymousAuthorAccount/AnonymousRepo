import os
import json
import hashlib

def calculate_file_hash(file_path, hash_algo='sha256'):
    # 创建哈希对象
    hasher = hashlib.new(hash_algo)
    
    # 以二进制方式读取文件并更新哈希对象
    with open(file_path, 'rb') as file:
        while chunk := file.read(8192):
            hasher.update(chunk)
    
    # 返回十六进制表示的哈希值
    return hasher.hexdigest()

class Resource:
    def __init__(self, path, save_path, apk=True, load=False):
        self.apk = apk
        self.save_path = save_path
        self.basename = os.path.basename(path)
        self.resources = []
        self.RT = {}
        if not load:
            self.basedir = f"/root/bolin/TPLDetection/TPLDAgent/TMP/{self.basename}"
            if os.path.exists(self.basedir):
                os.system(f'rm -rf {self.basedir}/*')
            else:
                os.system(f"mkdir {self.basedir}")
            self.unzip_path = f"{self.basedir}/{self.basename}"
            os.system(f"cd {self.basedir} && cp {path} {self.basedir} && unzip {self.unzip_path}")
            self.ExtractRes(self.basedir)
            # print(self.resources)
            self.save()
            os.system(f"rm -rf {self.unzip_path}")
        else:
            self.load()
    
    def ExtractRes(self, basedir):
        res_path = os.path.join(basedir, 'res/')
        if os.path.exists(res_path):
            for root, dirs, files in os.walk(res_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    self.resources.append(file_path)
                    
    def save(self):
        for item in self.resources:
            # print(item)
            self.RT[item.replace(self.basedir, '')] = {"hash": calculate_file_hash(item), "ext": item.split('.')[-1]}
            
        if len(self.RT):
            with open(self.save_path, 'w') as f:
                json.dump(self.RT, f)
    
    
    def load(self):
        if os.path.exists(self.save_path):
            with open(self.save_path) as f:
                self.RT = json.load(f)
        
        
if __name__ == '__main__':
    rt = Resource("/root/bolin/dataset_obfus_unobfus/D2/apps/allatori-ar.com.tristeslostrestigres.diasporanativewebapp.apk", "allatori-ar.com.tristeslostrestigres.diasporanativewebapp.json")
    print(rt.RT)