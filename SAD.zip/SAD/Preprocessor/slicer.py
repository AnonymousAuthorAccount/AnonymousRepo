
BLIST = [
    "Landroid/os/",
    "Landroid/text/",
    "Landroid/util/",
    "Landroid/webkit/",
    "Landroid/net/",
    "Landroid/database/",
    "Landroid/print/",
    "Landroid/transition/",
    "Landroid/hardware/",
    "Landroid/provider/",
    "Landroid/accessibilityservice/",
    "Landroid/speech/",
    "Landroid/location/",
    "Landroid/preference/",
    "Landroid/content/",
    "Landroid/view/",
    "Landroid/graphics/",
    "Landroid/widget/",
    
    "Ljava/lang/",
    "Ljava/util/",
    "Ljava/io/",
    "Ljava/text/",
    "Ljava/nio/",
    "Ljava/math/",
]

class DataflowSlicer:
    def __init__(self, param_registers, local_registers):
        self.param_registers = set(param_registers)  # 参数寄存器
        self.local_registers = set(local_registers)  # 局部变量寄存器
        self.usage_registers = set()  # 追踪当前使用中的寄存器
        self.last_instruction = None  # 用于追踪隐式依赖的上一条指令

    def is_dependency(self, operands):
        for opr in operands:
            if opr[0] == 0 and (opr[1] in self.param_registers or opr[1] in self.usage_registers):
                return True
        return False

    def handle_move_result(self, result_register):
        if self.last_instruction and self.is_dependency(self.last_instruction[1]):
            self.usage_registers.add(result_register)
            return True
        return False

    def update_usage_registers(self, dest_reg, src_operands):
        if self.is_dependency(src_operands):
            self.usage_registers.add(dest_reg)
        else:
            self.usage_registers.discard(dest_reg) 

    def isClassName(self, name):
        if not isinstance(name, str):
            return
        if not name.startswith("L") and not name.endswith(";"):
            return None
        
        prefix = ""
        while name.startswith('['):
            prefix += '['
            name = name[1:]

        for item in BLIST:
            if name.startswith(item):
                return prefix+name[1:-1].replace('/', '.')
            
        if name in ['V', 'B', 'C', 'D', 'F', 'I', 'J', 'S', 'Z']:
            return prefix+name
        
        return prefix+'SelfDefined'

    def slice_instructions(self, instructions):
        sliced_instructions = []

        for idx, (opcode, operands) in enumerate(instructions):
            if "move-result" in opcode:
                result_register = operands[0][1]
                if self.handle_move_result(result_register):
                    sliced_instructions.append(opcode)
                self.last_instruction = None 

            else:
                dest_reg = None
                src_operands = []
                for opr in operands:
                    if opr[0] == 0:
                        if dest_reg is None:
                            dest_reg = opr[1] 
                        else:
                            src_operands.append((opr[0], opr[1]))

                if dest_reg in self.param_registers or self.is_dependency(operands):
                    if ('new' in opcode or 'invoke' in opcode or 'object' in opcode) and self.isClassName(operands[-1][-1]):
                        sliced_instructions.append(opcode+'-'+self.isClassName(operands[-1][-1]))
                    else:
                        sliced_instructions.append(opcode)

                if dest_reg is not None:
                    self.update_usage_registers(dest_reg, src_operands)

                self.last_instruction = (opcode, operands)

        return sliced_instructions

def get_mtd_slice(mtd):
    if "abstract" in mtd.get_access_flags_string() or "interface" in mtd.get_access_flags_string():
        return []
    
    if len(list(mtd.get_instructions())) == 0:
        return []

    try:
        local_registers = set(range(1, mtd.get_locals()+1))
        param_registers = set(item+1 for item in range(len(local_registers), mtd.get_locals()+len(mtd.get_descriptor()[mtd.get_descriptor().find('('):mtd.get_descriptor().rfind(')')].split(' '))))

        instructions = [(inst.get_name(), inst.get_operands()) for inst in mtd.get_instructions()]
        slicer = DataflowSlicer(param_registers, local_registers)
        sliced = slicer.slice_instructions(instructions)

        slice = []
        for item in sliced:
            if "move" in item or "nop" in item or '-to-' in item or "switch" in item:
                continue
            if '/' in item:
                slice.append(item.split('/')[0])
            elif 'if' in item:
                slice.append("if")
            else:
                slice.append(item)
    except Exception as e:
        print(e)
        slice = []
    return slice