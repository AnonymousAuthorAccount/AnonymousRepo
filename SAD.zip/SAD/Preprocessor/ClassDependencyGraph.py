
import os
import json
from typing import List
import networkx as nx
import multiprocessing
from collections import defaultdict
from androguard.core.bytecodes.dvm import ClassDefItem, EncodedMethod
from androguard.misc import AnalyzeAPK, AnalyzeDex
from collections import defaultdict, Counter

from .slicer import get_mtd_slice

BLIST = [
    "Landroid/os/",
    "Landroid/text/",
    "Landroid/util/",
    "Landroid/webkit/",
    "Landroid/net/",
    "Landroid/database/",
    "Landroid/print/",
    "Landroid/transition/",
    "Landroid/hardware/",
    "Landroid/provider/",
    "Landroid/accessibilityservice/",
    "Landroid/speech/",
    "Landroid/location/",
    "Landroid/preference/",
    "Landroid/content/",
    "Landroid/view/",
    "Landroid/graphics/",
    "Landroid/widget/",
    
    "Ljava/lang/",
    "Ljava/util/",
    "Ljava/io/",
    "Ljava/text/",
    "Ljava/nio/",
    "Ljava/math/",
]


class ClassNode:
    def __init__(self, id:int, clzName:str, access_flags:str, members:List[str], sourceCode, fields_usage, fields_type, in_class_src_fields, methods_infos, fld_init_value, summary=None):
        self.id = id
        self.sourceCode = sourceCode
        self.clzName = clzName
        self.access_flags = access_flags
        self.members = members
        self.fields_usage = fields_usage
        self.fields_type = fields_type
        self.in_class_src_fields = in_class_src_fields
        self.fld_init_value = fld_init_value
        self.methods_infos = methods_infos
        self.implements = list()
        self.extends = None
        self.fldref = list()  
        self.invocations = list()
        self.classDeps = list()
        self.retTypes = list()
        self.paramTypes = list()
        self.summary = summary
        self.matched_id = -1
        self.matched_score = -1
        self.clean = False
        
        self.clzName_Obufs_Agent = 10
        self.pkgName_Obufs_Agent = 10
        
    def convert2json(self):
        res = {}
        res['id'] = self.id
        res["sourceCode"] = self.sourceCode
        res["clzName"] = self.clzName
        res["access_flags"] = self.access_flags
        res["members"] = self.members
        res["implements"] = self.implements
        res["extends"] = self.extends
        res["fldref"] = self.fldref
        res["invocations"] = self.invocations
        res["summary"] = self.summary
        res["methods_infos"] = self.methods_infos
        res["fields_usage"] = self.fields_usage
        res["fields_type"] = self.fields_type
        res["in_class_src_fields"] = self.in_class_src_fields
        res["fld_init_value"] = self.fld_init_value
        res["classDependencies"] = self.classDeps
        res["retTypes"] = self.retTypes
        res["paramTypes"] = self.paramTypes
        return res
    
    def add_extends(self, extends:int):
        '''id of extended class'''
        self.extends = extends  
        
    def add_implements(self, implements:List[int]):
        '''ids of implemented interfaces'''
        self.implements = implements
            
    def add_references(self, references:List[int]):
        '''id of references'''
        self.fldref = references
    
    def add_classdeps(self, clzdeps):
        self.classDeps = clzdeps

        

class CDG:
    def __init__(self):
        self.incId = 0
        self.id2node = {}
        self.desp2id = {}
        self.longest_dep_path = 0

    def add_node(self, clzNode):
        self.id2node[self.incId] = clzNode
        self.desp2id[clzNode.clzName] = self.incId
        self.incId += 1

    def save(self, path):
        write_format = {}
        write_format["desp2id"] = self.desp2id
        write_format["longest_path"] = self.longest_dep_path
        write_format["id2node"] = {}
        for key in self.id2node:
            write_format["id2node"][key] = self.id2node[key].convert2json()
        with open(path, 'w') as f:
            json.dump(write_format, f)
            
            
    def load(self, path):
        if not os.path.exists(path):
            return None
        
        with open(path) as f:
            read_format = json.load(f)
        self.desp2id = read_format["desp2id"]
        self.longest_dep_path = int(read_format["longest_path"])
        for id in read_format["id2node"]:
            nodeinfo = read_format["id2node"][id]
            clzNode = ClassNode(nodeinfo['id'], 
                                nodeinfo['clzName'], 
                                nodeinfo['access_flags'], 
                                nodeinfo['members'], 
                                nodeinfo['sourceCode'], 
                                fields_usage=nodeinfo['fields_usage'],
                                fields_type=nodeinfo['fields_type'],
                                in_class_src_fields=nodeinfo['in_class_src_fields'],
                                methods_infos=nodeinfo['methods_infos'],
                                fld_init_value=nodeinfo['fld_init_value'],
                                summary=nodeinfo['summary'])
            clzNode.add_extends(nodeinfo['extends'])
            clzNode.add_implements(nodeinfo['implements'])
            clzNode.add_references(nodeinfo['fldref'])
            clzNode.invocations = nodeinfo['invocations']
            clzNode.classDeps = nodeinfo['classDependencies']
            clzNode.retTypes = nodeinfo['retTypes']
            clzNode.paramTypes = nodeinfo['paramTypes']

            self.id2node[int(id)] = clzNode


    def getNodeAttrs(self):
        nodeattr = {}
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            new_access_flags = []
            if "interface" in node.access_flags:
                new_access_flags.append("interface")
                
            if "abstract" in node.access_flags:
                new_access_flags.append("abstract")
                
            if "static" in node.access_flags:
                new_access_flags.append("static")
            if len(new_access_flags):
                nodeattr[desp] = ' '.join(new_access_flags)
            else:
                nodeattr[desp] = "None"
                
        return nodeattr

    def getEdgeAttrs_ForSimGraph(self):
        graph = {}
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            
            graph[desp] = []
            if node.extends is not None:
                if isinstance(node.extends, int):
                    graph[desp].append(("extends", self.id2node[node.extends].clzName))
                else:
                    graph[desp].append(("extends", node.extends))
            for imp in node.implements:
                if isinstance(imp, int):
                    graph[desp].append(("implements", self.id2node[imp].clzName))
                else:
                    graph[desp].append(("implements", imp))
            for ref in node.fldref:
                if isinstance(ref, int):
                    graph[desp].append(("reference", self.id2node[ref].clzName))
                else:
                    graph[desp].append(("reference", ref))

        return graph
    
    def getEdgeAttrs(self):
        graph = {}
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            
            graph[desp] = []
            if node.extends is not None:
                if isinstance(node.extends, int):
                    graph[desp].append(("extends", self.id2node[node.extends].clzName))
                else:
                    graph[desp].append(("extends", node.extends))
            for imp in node.implements:
                if isinstance(imp, int):
                    graph[desp].append(("implements", self.id2node[imp].clzName))
                else:
                    graph[desp].append(("implements", imp))
            for ref in node.fldref:
                if isinstance(ref, int):
                    graph[desp].append(("reference", self.id2node[ref].clzName))
                else:
                    graph[desp].append(("reference", ref))
            for clz in node.retTypes:
                if isinstance(clz, int):
                    graph[desp].append(("retType", self.id2node[clz].clzName))
                else:
                    graph[desp].append(("retType", clz))
            for clz in node.paramTypes:
                if isinstance(clz, int):
                    graph[desp].append(("paramType", self.id2node[clz].clzName))
                else:
                    graph[desp].append(("paramType", clz))
            
        return graph

    def no_member_nodes(self):
        nodes = []
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            if len(node.members) == 0:
                nodes.append(desp)
        return nodes
    
    def get_node_sourceCode(self):
        sourceCodes = {}
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            if "interface" in node.access_flags or 'abstract' in node.access_flags:
                continue
            
            sourceCodes[desp] = node.sourceCode
        return sourceCodes

    def getGraph_Simple(self):
        graph = {}
        for desp in self.desp2id:
            node = self.id2node[self.desp2id[desp]]
            graph[desp] = []
            
            if node.extends is not None:
                if isinstance(node.extends, int):
                    graph[desp].append(self.id2node[node.extends].clzName)

            for imp in node.implements:
                if isinstance(imp, int):
                    graph[desp].append(self.id2node[imp].clzName)
                    
            for ref in node.fldref:
                if isinstance(ref, int):
                    graph[desp].append(self.id2node[ref].clzName)
            
            for clz in node.classDeps:
                if isinstance(clz, int):
                    graph[desp].append(self.id2node[clz].clzName)

        return graph
    

def CreateClassDependencyGraph(path, classes=None, apk=False, load=False, CDG_save_path=""):
    if load and os.path.exists(CDG_save_path):
        try:
            _CDG = CDG()
            _CDG.load(CDG_save_path)
            return _CDG
        except Exception as e:
            print("Load Failed", e)
            
    if apk:
        a, d, dx = AnalyzeAPK(path)
        if classes is None:
            classes = []
            for _d in d:
                for clz in _d.get_classes():
                    if not clz.get_name().split('/')[-1].startswith('R$'):
                        classes.append(clz)
                    
        _CDG = parseAndBuild(d, dx, classes, apk, path)
        if CDG_save_path != "":
            _CDG.save(CDG_save_path)
    else:
        _, d, dx = AnalyzeDex(path)
        classes = d.get_classes()
        
        _CDG = parseAndBuild(d, dx, classes, apk, path)
        if CDG_save_path != "":
            _CDG.save(CDG_save_path)

    return _CDG
    
def split_array(arr, n):
    k, m = divmod(len(arr), n)
    groups = [arr[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n)]
    return groups

def clznameType(name):
    if name.startswith('['):
        prefix = name[:name.rfind('[')+1]
        name = name.strip(prefix)
    else:
        prefix = ""
    for item in BLIST:
        if name.startswith(item):
            return prefix+name
    if name in ['V', 'B', 'C', 'D', 'F', 'I', 'J', 'S', 'Z']:
        return prefix+name
    return prefix+'SelfDefined'

def get_field_usage(clzname, dx, fields_type):
    fields_usage = {}
    target_class = dx.get_class_analysis(clzname)
    for mtd in target_class.get_vm_class().get_methods():
        mtd_desp = mtd.get_name() + mtd.get_descriptor() +' ' + mtd.get_access_flags_string().replace("0x0", "public")
        fields_usage[mtd_desp] = {}
    
    for fld in target_class.get_fields():
        for (classobj, mtdobj) in fld.get_xref_read():
            if fld.get_field().get_class_name() == clzname and fld.name in fields_type:
                mtd_desp = mtdobj.get_name()+mtdobj.get_descriptor()+' ' + mtdobj.get_access_flags_string().replace("0x0", "public")
                if "read" not in fields_usage[mtd_desp]:
                    fields_usage[mtd_desp]['read'] = defaultdict(int)
                fields_usage[mtd_desp]['read'][fld.name] += 1
        
        for (classobj, mtdobj) in fld.get_xref_write():
            if fld.get_field().get_class_name() == clzname and fld.name in fields_type:
                mtd_desp = mtdobj.get_name()+mtdobj.get_descriptor()+' ' + mtdobj.get_access_flags_string().replace("0x0", "public")
                if "write" not in fields_usage[mtd_desp]:
                    fields_usage[mtd_desp]['write'] = defaultdict(int)
                fields_usage[mtd_desp]['write'][fld.name] += 1
    return fields_usage

def get_methods_info(methods, clzname, path, dx):
    mtdsSigs = {}
    mtdOpcodes = {}
    mtdOperands = {}
    mtdCodes = {}
    self_invocations = {}
    mtdSlice = {}
    for mtd in methods:
        desp = mtd.get_descriptor()
        if desp.find('(')+1 == desp.rfind(')'):
            arguments = ""
        else:
            arguments = ' '.join([clznameType(item) for item in desp[desp.find('(')+1:desp.rfind(')')].split(' ')])
        
        mtd_sig = '('+arguments+')' + clznameType(desp.split(')')[-1]) + (" static" if "static" in mtd.get_access_flags_string().replace("0x0", "public") else "") + \
                                        (" constructor" if "constructor" in mtd.get_access_flags_string().replace("0x0", "public") else "")
        
        desp = mtd.get_name()+mtd.get_descriptor()+' '+mtd.get_access_flags_string().replace("0x0", "public")
        if mtd.get_name() == '<init>' or mtd.get_name() == '<clinit>':
            mtdsSigs[desp] = mtd.get_name()+mtd_sig
        else:
            mtdsSigs[desp] = mtd_sig
        
        mtdOpcodes[desp] = list()
        mtdOperands[desp] = list()
        for inst in mtd.get_instructions():
            mtdOpcodes[desp].append(inst.get_name().split('/')[0])
            if ("const" in inst.get_name() and inst.get_name() != "const-class") or inst.get_name() == "fill-array-data-payload":
                try:
                    mtdOperands[desp].append(inst.get_operands()[-1][-1])
                except Exception as e:
                    print(e)

        try:
            mtdCodes[desp] = mtd.get_source()
        except Exception as e:
            mtdCodes[desp] = None
            
        self_invocations[desp] = []

        mtdSlice[desp] = get_mtd_slice(mtd)
            
    for aly_mtd in dx.get_class_analysis(clzname).get_methods():
        mtd = aly_mtd.get_method()
        desp = mtd.get_name()+mtd.get_descriptor()+' '+mtd.get_access_flags_string().replace("0x0", "public")
        if desp not in self_invocations:
            continue
        for clsAy, emtd, offset in aly_mtd.get_xref_to():
            if clsAy.name == clzname and isinstance(EncodedMethod, EncodedMethod):
                edesp = emtd.get_name()+emtd.get_descriptor()+' '+emtd.get_access_flags_string().replace("0x0", "public")
                if edesp not in self_invocations:
                    continue
                self_invocations[desp].append(edesp)

    return mtdsSigs, mtdOpcodes, mtdOperands, mtdCodes, self_invocations, mtdSlice


def worker(nodes, classes, d, dx, path):
    for clz in classes:
        clz_src_code = clz.get_source()
        fld_init_value = defaultdict(list)
        members = []
        fields_type = {}
        in_class_src_fields = []
        for fld in clz.get_fields():
            fields_type[fld.get_name()] = fld.get_descriptor()
            if fld.get_name() in clz_src_code:
                in_class_src_fields.append(fld.get_name())
            members.append("[FIELD]"+clznameType(fld.get_descriptor())+"|"+fld.get_access_flags_string().replace("0x0", "public"))
            if fld.get_init_value() is not None:
                if isinstance(fld.get_init_value().get_value(), int):
                    fld_init_value[fld.get_name()+'|'+clznameType(fld.get_descriptor())+"|"+fld.get_access_flags_string().replace("0x0", "public")].append(fld.get_init_value().get_value())
                else:
                    fld_init_value[fld.get_name()+'|'+clznameType(fld.get_descriptor())+"|"+fld.get_access_flags_string().replace("0x0", "public")].append(str(fld.get_init_value().get_value()))
            
        for mtd in clz.get_methods():
            desp = mtd.get_descriptor()
            if desp.find('(')+1 == desp.rfind(')'):
                arguments = ""
            else:
                arguments = ' '.join([clznameType(item) for item in desp[desp.find('(')+1:desp.rfind(')')].split(' ')])
            if mtd.get_name() == '<init>' or mtd.get_name() == '<clinit>':
                members.append("[METHOD]"+mtd.get_name()+'('+arguments+')'+clznameType(desp.split(')')[-1])+"|"+mtd.get_access_flags_string().replace("0x0", "public"))
            else:
                members.append("[METHOD]"+'('+arguments+')'+clznameType(desp.split(')')[-1])+"|"+mtd.get_access_flags_string().replace("0x0", "public"))
            
        fields_usage = get_field_usage(clz.get_name(), dx, fields_type)
        
        mtdsSig4Executor, mtdOpcodes, mtdOperands, methodCode, self_invocations, mtdSlice = get_methods_info(clz.get_methods(), clz.get_name(), path, dx)
        methods_infos = {
            "methodSignatures": mtdsSig4Executor,
            "methodOpcodes": mtdOpcodes,
            "methodOperands": mtdOperands,
            "methodCodes": methodCode,
            "methodSlice": mtdSlice,
            "self-invocations": self_invocations
        }
        clzNode = ClassNode(0, clz.get_name(), clz.get_access_flags_string().replace("0x0", "public"), members, clz.get_source(), fields_usage=fields_usage, fields_type=fields_type, in_class_src_fields=in_class_src_fields, methods_infos=methods_infos, fld_init_value=fld_init_value)
        nodes.append(clzNode)
    
def parseAndBuild(d, dx, classes:List[ClassDefItem], apk, path):
    _CDG = CDG()
    if not apk:
        dependency_graph = nx.DiGraph()
        
    numproc = 8
    splited_classes = split_array(classes, numproc)
    manager = multiprocessing.Manager()
    shared_list = manager.list()
    
    processes = []
    for i in range(numproc):
        p = multiprocessing.Process(target=worker, args=(shared_list, splited_classes[i], d, dx, path))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
        
    nodes = list(shared_list)
    for i,node in enumerate(nodes):
        node.id = _CDG.incId
        _CDG.add_node(node)
        if not apk:
            dependency_graph.add_node(node.clzName)
    
    for clz in classes:
        if clz.get_name() not in _CDG.desp2id:
            print(clz.get_name())
        
        clzid = _CDG.desp2id[clz.get_name()]
        clzNode: ClassNode = _CDG.id2node[clzid]
        superclz = clz.get_superclassname()
        if superclz in _CDG.desp2id:
            superclzid = _CDG.desp2id[superclz]
            clzNode.add_extends(superclzid)
        else:
            clzNode.add_extends(superclz)
        if not apk:
            dependency_graph.add_edge(clz.get_name(), superclz)
        
        implements = list()
        for itfc in clz.get_interfaces():
            if itfc not in _CDG.desp2id:
                if itfc not in implements:
                    implements.append(itfc)
                if not apk:
                    dependency_graph.add_edge(clz.get_name(), itfc)
                continue
            itfcid = _CDG.desp2id[itfc]
            itfcNode = _CDG.id2node[itfcid]
            if itfcid not in implements:
                implements.append(itfcid)
            if not apk:
                dependency_graph.add_edge(clz.get_name(), itfcNode.clzName)
        clzNode.add_implements(implements)
        
        fldRefs = list()
        for fld in clz.get_fields():
            fld_type = fld.get_descriptor()
            if fld_type in _CDG.desp2id:
                if _CDG.desp2id[fld_type] not in fldRefs:
                    fldRefs.append(_CDG.desp2id[fld_type])
                clzRef = _CDG.id2node[_CDG.desp2id[fld_type]]
                if not apk:
                    dependency_graph.add_edge(clz.get_name(), clzRef.clzName)
            else:
                if fld_type not in fldRefs:
                    fldRefs.append(fld_type)
                if not apk:
                    dependency_graph.add_edge(clz.get_name(), fld_type)
        clzNode.add_references(fldRefs)
        
        clzDep = list()
        retTypes = list()
        paramTypes = list()
        for mtd in clz.get_methods():
            retype = mtd.get_descriptor().split(')')[-1]
            if retype in _CDG.desp2id:
                if _CDG.desp2id[retype] not in clzDep:
                    clzDep.append(_CDG.desp2id[retype])
                if _CDG.desp2id[retype] not in retTypes:
                    retTypes.append(_CDG.desp2id[retype])
                clzRef = _CDG.id2node[_CDG.desp2id[retype]]
                if not apk:
                    dependency_graph.add_edge(clz.get_name(), clzRef.clzName)
                    
            else:
                if retype not in clzDep:
                    clzDep.append(retype)
                if retype not in retTypes:
                    retTypes.append(retype)
                if not apk:
                    dependency_graph.add_edge(clz.get_name(), retype)
            
            if mtd.get_descriptor().split('(')[-1].split(')')[0] != "":
                for tp in mtd.get_descriptor().split('(')[-1].split(')')[0].split(' '):
                    if tp in _CDG.desp2id:
                        if _CDG.desp2id[tp] not in clzDep:
                            clzDep.append(_CDG.desp2id[tp])
                        if _CDG.desp2id[tp] not in paramTypes:
                            paramTypes.append(_CDG.desp2id[tp])
                        clzRef = _CDG.id2node[_CDG.desp2id[tp]]
                        if not apk:
                            dependency_graph.add_edge(clz.get_name(), clzRef.clzName)
                    else:
                        if tp not in clzDep:
                            clzDep.append(tp)
                        if tp not in paramTypes:
                            paramTypes.append(tp)
                        if not apk:
                            dependency_graph.add_edge(clz.get_name(), tp)
        
        clzNode.add_classdeps(clzDep)
        clzNode.retTypes = retTypes
        clzNode.paramTypes = paramTypes
                
    if not apk:
        longest_path = 0
        for node in dependency_graph.nodes:
            try:
                lengths = nx.single_source_dijkstra_path_length(dependency_graph, node)
                max_length = max(lengths.values())
                longest_path = max(longest_path, max_length)
            except nx.NetworkXNoPath:
                continue
        _CDG.longest_dep_path = longest_path
    
    return _CDG
