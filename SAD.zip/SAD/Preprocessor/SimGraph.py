import numpy as np
import os, sys
import hashlib
sys.path.append(os.getcwd())
from collections import defaultdict
from Preprocessor.ClassDependencyGraph import BLIST


class LSH:
    def __init__(self, num_hashes=200):
        self.num_hashes = num_hashes

    def stable_hash(self, token, seed):
        # Generate a stable hash using hashlib
        hasher = hashlib.sha256()
        hasher.update(f"{token}-{seed}".encode('utf-8'))
        return int(hasher.hexdigest(), 16)

    def compute_minhash(self, tokens):
        # Create a set of unique tokens
        unique_tokens = set([''.join(map(str, token)) for token in tokens])
        # Create a binary vector for each token
        vector = [0 for _ in range(self.num_hashes)]
        for i in range(self.num_hashes):
            # Use stable_hash for consistent hashing
            hash_values = [self.stable_hash(token, i) % self.num_hashes for token in unique_tokens]
            # Set the corresponding position in the vector
            vector[i] = min(hash_values)

        return vector


class WLHeterogeneous:
    def __init__(self, h=2, similarity_threshold=.85):
        self.h = h
        self.hash_function = LSH()
        self.similarity_threshold = similarity_threshold
        
    def cosine_similarity(self, vec1, vec2):
        vec1 = np.array(vec1)
        vec2 = np.array(vec2)
        
        dot_product = np.dot(vec1, vec2)
        
        norm_vec1 = np.linalg.norm(vec1)
        norm_vec2 = np.linalg.norm(vec2)
        
        if norm_vec1 == 0 or norm_vec2 == 0:
            return 0.0
        else:
            return dot_product / (norm_vec1 * norm_vec2)

    def fit_transform(self, graph, node_types, refMiss, extendsMiss, implMiss):
        labels = {node: node_types[node] for node in graph}
        Others = {}
        if refMiss:
            Others['reference'] = {node: node_types[node] for node in graph}
        if extendsMiss:
            Others['extends'] = {node: node_types[node] for node in graph}
        if implMiss:
            Others['implements'] = {node: node_types[node] for node in graph}

        for i in range(self.h):
            labels, Others = self.update_labels(graph, labels, i, others=Others)
        
        return labels, Others


    def update_labels(self, graph, labels, i, others=None):
        new_labels = {}
        new_labels_others = {key:{} for key in others}
        
        for node in graph:
            neighborhood = []
            neighborhood_others = {key:[] for key in others}

            for edge_type, neighbor in graph[node]:

                arr_num = 0
                while neighbor[0] == '[':
                    arr_num += 1
                    neighbor = neighbor[1:]
                if arr_num:
                    arr_num = "Array"*arr_num
                else:
                    arr_num = ""

                if neighbor in labels:
                    if neighbor == node:
                        neighborhood.append(arr_num+f"{edge_type} SELF")
                    else:
                        if isinstance(labels[neighbor], list):
                            neighborhood.append(arr_num+f"{edge_type} {''.join([str(item) for item in labels[neighbor]])}")
                        else:
                            neighborhood.append(arr_num+f"{edge_type} {labels[neighbor]}")
                else:
                    neighborhood.append(arr_num+f"{edge_type} {neighbor}")
                
                if "extends" in others and edge_type != "extends":
                    if neighbor in others["extends"]:
                        if neighbor == node:
                            neighborhood_others["extends"].append(arr_num+f"{edge_type} SELF")
                        else:
                            if isinstance(others["extends"][neighbor], list):
                                neighborhood_others["extends"].append(arr_num+f"{edge_type} {''.join([str(item) for item in others['extends'][neighbor]])}")
                            else:
                                neighborhood_others["extends"].append(arr_num+f"{edge_type} {others['extends'][neighbor]}")
                    else:
                        neighborhood_others["extends"].append(arr_num+f"{edge_type} {neighbor}")
                if "implements" in others and edge_type != "implements":
                    if neighbor in others["implements"]:
                        if neighbor == node:
                            neighborhood_others["implements"].append(arr_num+f"{edge_type} SELF")
                        else:
                            if isinstance(others["implements"][neighbor], list):
                                neighborhood_others["implements"].append(arr_num+f"{edge_type} {''.join([str(item) for item in others['implements'][neighbor]])}")
                            else:
                                neighborhood_others["implements"].append(arr_num+f"{edge_type} {others['implements'][neighbor]}")
                    else:
                        neighborhood_others["implements"].append(arr_num+f"{edge_type} {neighbor}")
                if "reference" in others and edge_type != "reference":
                    if neighbor in others["reference"]:
                        if neighbor == node:
                            neighborhood_others["reference"].append(arr_num+f"{edge_type} SELF")
                        else:
                            if isinstance(others["reference"][neighbor], list):
                                neighborhood_others["reference"].append(arr_num+f"{edge_type} {''.join([str(item) for item in others['reference'][neighbor]])}")
                            else:
                                neighborhood_others["reference"].append(arr_num+f"{edge_type} {others['reference'][neighbor]}")
                    else:
                        neighborhood_others["reference"].append(arr_num+f"{edge_type} {neighbor}")
                
            neighborhood.sort()
            for key in neighborhood_others:
                neighborhood_others[key].sort()

            if isinstance(labels[node], list):
                neighborhood.append(''.join([str(item) for item in labels[node]]))
            else:
                neighborhood.append(labels[node])

            for key in neighborhood_others:
                if isinstance(others[key][node], list):
                    neighborhood_others[key].append(''.join([str(item) for item in others[key][node]]))
                else:
                    neighborhood_others[key].append(others[key][node])

            new_labels[node] = self.hash_function.compute_minhash(neighborhood)
            for key in neighborhood_others:
                new_labels_others[key][node] = self.hash_function.compute_minhash(neighborhood_others[key])

        return new_labels, new_labels_others
    
    def isStdLib(self, name):
        for item in BLIST:
            if name.startswith(item):
                return True
        return False

    def getClass(self, clzname):
        while clzname[0] == '[':
            clzname = clzname[1:]
        return clzname
    
    def isExtClass(self, clzname):
        clzname = self.getClass(clzname)
        for item in BLIST:
            if clzname.startswith(item):
                return True
        if clzname in ['B', 'C', 'D', 'F', 'I', 'J', 'S', 'Z', 'V']:
            return True
        return False

    def compute_similarity(self, graph1, graph2, node_types1, node_types2, tpl_nomember_nodes):
        refMiss = False
        extendsMiss = False
        implMiss = False
        for key2 in graph2:
            for etype, neighbor in graph2[key2]:
                if self.getClass(neighbor) not in graph2 and not self.isExtClass(neighbor):
                    if etype == 'extends':
                        extendsMiss = True
                    elif etype == 'reference':
                        refMiss = True
                    elif etype == 'implements':
                        implMiss = True
                    break
        labels1, others1 = self.fit_transform(graph1, node_types1, refMiss, extendsMiss, implMiss)
        labels2, others2 = self.fit_transform(graph2, node_types2, refMiss, extendsMiss, implMiss)
        
        similar_pairs = {}
        blist = set()
                
        for key2 in labels2:
            ExternalDepType = None
            for etype, neighbor in graph2[key2]:
                if self.getClass(neighbor) not in graph2 and not self.isExtClass(neighbor):
                    ExternalDepType = etype
                    break
            
            for key1 in labels1:
                if key2 == key1:
                    similar_pairs[key2] = [key1]
                    blist.add(key1)
                    break
            
                if key1 in blist:
                    continue
                
                if self.isStdLib(key1):
                    continue

                if ExternalDepType is None:
                    similarity = self.cosine_similarity(labels1[key1], labels2[key2])
                else:
                    similarity = self.cosine_similarity(others1[ExternalDepType][key1], others2[ExternalDepType][key2])
                if similarity >= self.similarity_threshold:
                    if key2 not in similar_pairs:
                        similar_pairs[key2] = []
                    similar_pairs[key2].append(key1)
                
        return similar_pairs
