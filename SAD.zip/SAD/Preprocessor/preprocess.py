
import os
import copy
import json
import loguru
from Preprocessor.ClassDependencyGraph import CreateClassDependencyGraph
from Preprocessor.SimGraph import WLHeterogeneous
from Preprocessor.Resource import Resource


class Preprocess:
    def __init__(self, apkpath, tplpaths, load, cache):
        self.apkpath = apkpath
        self.tplpaths = tplpaths
        self.load = load
        self.use_cache = cache
        self.APKData = None
        self.TPLData = {'CDG': {}, 'Res': {}}
        self.apkCDGpath = "/root/TPLDAgent/SAD/SAD-main/CDGs/APK"
        self.tplCDGpath = "/root/TPLDAgent/SAD/SAD-main/CDGs/TPL"
        # self.apkCDGpath = os.getcwd()+"/CDGs/APK"
        # self.tplCDGpath = os.getcwd()+"/CDGs/TPL"
        self.apkRTpath = os.getcwd()+"/Res/APK"
        self.tplRTpath = os.getcwd()+"/Res/TPL"
        self.cacheDir = os.getcwd()+"/WL"
        self.TPLhasRes = False
        with open("config/HyperParams.json") as f:
            self.hyperparams = json.load(f)
        self.APKData = CreateClassDependencyGraph(self.apkpath, load=self.load, apk=True, CDG_save_path=f"{self.apkCDGpath}/{os.path.basename(self.apkpath)}.json")
        self.APKRes = Resource(self.apkpath, save_path=f"{self.apkRTpath}/{os.path.basename(self.apkpath)}.json", load=True).resources
        for path in tplpaths:
            basename = os.path.basename(path)
            self.TPLData['CDG'][basename] = CreateClassDependencyGraph(path, load=self.load, CDG_save_path=f"{self.tplCDGpath}/{basename}.json")
            self.TPLData['Res'][basename] = Resource(path, save_path=f"{self.tplRTpath}/{basename}.json", load=True).resources
            if len(self.TPLData['Res'][basename]):
                self.TPLhasRes = True

        self.WL()
    
    def WL(self):
        self.wl_MatchPairs = {}
        for path in self.tplpaths:
            basename = os.path.basename(path)
            
            cache = f"{self.cacheDir}/{os.path.basename(self.apkpath)}/{basename}.json"

            if os.path.exists(cache) and self.use_cache:
                with open(cache) as f:
                    self.wl_MatchPairs[basename] = json.load(f)
                continue
            
            apknodes = self.APKData.getNodeAttrs()
            apkgraph = self.APKData.getEdgeAttrs_ForSimGraph()
            tplnodes = self.TPLData['CDG'][basename].getNodeAttrs()
            tplgraph = self.TPLData['CDG'][basename].getEdgeAttrs_ForSimGraph()
            if self.TPLData['CDG'][basename].longest_dep_path == 0:
                wl_kernel = WLHeterogeneous(h=1, similarity_threshold=self.hyperparams['similarity_threshold'])
            else:
                wl_kernel = WLHeterogeneous(h=self.TPLData['CDG'][basename].longest_dep_path, similarity_threshold=self.hyperparams['similarity_threshold'])
            self.wl_MatchPairs[basename] = wl_kernel.compute_similarity(apkgraph, tplgraph, apknodes, tplnodes, self.TPLData['CDG'][basename].no_member_nodes())

            if not os.path.exists(cache[:cache.rfind('/')]):
                os.makedirs(cache[:cache.rfind('/')])
            with open(cache, 'w') as f:
                json.dump(self.wl_MatchPairs[basename], f)
    