import os
import json
import argparse
import multiprocessing
from datetime import datetime
from Navigator.Navigator import Navigator

def split_array(arr, n):
    k, m = divmod(len(arr), n)
    groups = [arr[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n)]
    return groups

def SAD_worker(apps, libs, output, log_dir, load, tune, cache):
    for app_path in apps:
        app = os.path.basename(app_path)
        if not os.path.exists(os.path.join(output, app)):
            os.makedirs(os.path.join(output, app))

        for lib in os.listdir(libs):
            print(app, lib)
            lib_dir = os.path.join(libs, lib)
            assert os.path.isdir(lib_dir)

            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d_%H-%M-%S")
            LibGPT = Navigator(
                app=app_path,
                lib=lib_dir,
                log_dir=log_dir,
                load=load,
                cache=cache,
                curttime=formatted_time,
            )
            result = LibGPT(tune_param=tune)
            with open(os.path.join(output, app, lib+'.json'), "w") as f:
                json.dump(result, f)

def main():
    parser = argparse.ArgumentParser(description="SAD")
    
    parser.add_argument(
        "--apps",
        type=str,
        help="path of apps to detect.",
    )
    
    parser.add_argument(
        "--libs",
        type=str,
        help="dir of libs to detect.",
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default="results",
        help="path to the detection result.",
    )
    
    parser.add_argument(
        "--log_dir",
        type=str,
        default="logs/debug",
        help="path to the log directory.",
    )
    
    parser.add_argument(
        "--load",
        action="store_true",
        help="loading existing CDG data.",
    )

    parser.add_argument(
        "--tune",
        action="store_true",
        help="tune thresholds.",
    )
    
    parser.add_argument(
        "--cache",
        action="store_true",
        help="using WL cache.",
    )
    
    args = parser.parse_args()

    numproc = min(70, len(os.listdir(args.apps)))
    allapp = split_array([os.path.join(args.apps, app) for app in os.listdir(args.apps)], numproc)
    processes = []
    for i in range(numproc):
        p = multiprocessing.Process(target=SAD_worker, args=(allapp[i], args.libs, args.output, args.log_dir, args.load, args.tune, args.cache))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()

    
if __name__ == '__main__':
    main()

    # app = "/root/TPLDAgent/SAD/Dataset_v2/D1/apks/allatori-com.horaapps.leafpic.apk"
    # lib = "/root/TPLDAgent/SAD/Dataset_v2/D01_SAD_libs/com.android.support.palette-v7"
    
    # current_time = datetime.now()
    # formatted_time = current_time.strftime("%Y-%m-%d_%H-%M-%S")
    # LibGPT = Navigator(
    #     app=app,
    #     lib=lib,
    #     log_dir="logs/debug",
    #     load=True,
    #     cache=True,
    #     curttime=formatted_time
    # )
    # result = LibGPT()
    # with open("debug_result.json", "w") as f:
    #     json.dump(result, f)