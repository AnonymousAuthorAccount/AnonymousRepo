import os
import atexit
import inspect
from datetime import datetime

class Logger:
    def __init__(self, logpath, mod="a+"):
        self.logpath = logpath
        self.logger = open(logpath, mod)
        
    def __del__(self):
        self.logger.close()
    
    def close(self):
        self.logger.close()
        return
    
    def caller_info(self):
        stack = inspect.stack()
        frame = stack[3]
        module = inspect.getmodule(frame[0])
        filename = os.path.basename(module.__file__).split('.')[0] if module else ''
        lineno = frame.lineno
        function_name = frame.function
        class_name = frame[0].f_locals.get('self', None).__class__.__name__ if 'self' in frame[0].f_locals else None
        
        return filename, class_name, function_name, lineno
        
    def info(self, info, verbose=False):
        self.writeLog(info, "INFO", verbose)
        
    def debug(self, info, verbose=False):
        self.writeLog(info, "DEBUG", verbose)
        
    def warning(self, info, verbose=False):
        self.writeLog(info, "WARNING", verbose)
        
    def error(self, info, verbose=False):
        self.writeLog(info, "ERROR", verbose)
        
    def writeLog(self, info, level, verbose):
        module, class_name, function_name, lineno = self.caller_info()
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"{formatted_time} | {level:<8} | {module}.{class_name}:{function_name}:{lineno} - {info}")
        self.logger.write(f"{formatted_time} | {level:<8} | {module}.{class_name}:{function_name}:{lineno} - {info}\n")
        atexit.register(self.logger.flush)
        atexit.register(lambda: os.fsync(self.logger.fileno()))
        return
        