import os, sys
import json
import time
from collections import defaultdict, deque, Counter
sys.path.append(os.getcwd())
from utils.logger import Logger
from Preprocessor.ClassDependencyGraph import BLIST
from Preprocessor.preprocess import Preprocess
from Executor.Executor import Executor
from decimal import Decimal

class Navigator:  
    def __init__(self, 
                 app:str, 
                 lib:str, 
                 log_dir:str,
                 load:bool,
                 cache:bool,
                 curttime:str):
        self.APK = app
        self.TPLdir = lib
        self.TPLs = os.listdir(lib)
        self.log_dir = log_dir
        self.time = curttime
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)
            os.mkdir(os.path.join(self.log_dir, 'Navigator'))
            os.mkdir(os.path.join(self.log_dir, 'Executor'))
        
        
        self.Navigator_log = Logger(os.path.join(log_dir, "Navigator/", f"{os.path.basename(app)}_{os.path.basename(lib)}_{self.time}.log"), "a+")
        self.Executor_log = Logger(os.path.join(log_dir, "Executor/", f"{os.path.basename(app)}_{os.path.basename(lib)}_{self.time}.log"), "a+")

        self.Navigator_log.debug(f"[-] [APK] {os.path.basename(self.APK)}, [LIB] {os.path.basename(self.TPLdir)}")
        
        start_time = time.perf_counter()
        self.preprocessor = Preprocess(app, [os.path.join(self.TPLdir, lib) for lib in self.TPLs], load, cache)
        self.preprocess_time = time.perf_counter() - start_time
        
        with open("config/HyperParams.json") as f:
            hyperparams = json.load(f)
            
        self.node_match_threshold = hyperparams["node_match_threshold"]
        self.CDG_match_threshold = hyperparams["CDG_match_threshold"]
        self.high_confidence = hyperparams["high_confidence"]
        self.dm_weight = hyperparams["strongmathc_weight"]
        self.mtd_weight = hyperparams["method_weight"]

    def __finish__(self):
        self.Navigator_log.close()
        self.Executor_log.close()
        

    def __call__(self, tune_param=False, cdg_threshold=0.75, node_threshold=0.7):
        self.FAIL_CAUSE = {}
        if tune_param:
            self.CDG_match_threshold = cdg_threshold
            self.node_match_threshold = node_threshold

        self.cdg_match_result = []
        self.result = []
        self.infos = []
        
        self.consume_time = {}
        self.max_score = 0
        self.max_cdg_score = 0
            
        APKSimpleGraph = self.preprocessor.APKData.getGraph_Simple()
        APKAttrGraph = self.preprocessor.APKData.getEdgeAttrs()
        for tpl in self.TPLs:
            
                
            TPLSimpleGraph = self.preprocessor.TPLData['CDG'][tpl].getGraph_Simple()
            TPLAttrGraph = self.preprocessor.TPLData['CDG'][tpl].getEdgeAttrs()
            matchedpairs = self.preprocessor.wl_MatchPairs[tpl]
            
            nums = [len(matchedpairs[key]) for key in matchedpairs]
            if len(nums):
                self.Navigator_log.info(f"|--- {tpl} Avg Similar Pairs: {sum(nums)/len(nums)}, Total TPL class: {len(nums)}")
            
            start_time = time.perf_counter()
            match_scores = self.detect(matchedpairs, tpl)
            cdg_match_score, score, info = self.isMatch(match_scores, 
                                                        TPLSimpleGraph, 
                                                        APKSimpleGraph, 
                                                        self.preprocessor.TPLData['CDG'][tpl], 
                                                        TPLAttrGraph, 
                                                        APKAttrGraph,
                                                        tpl)
            end_time = time.perf_counter()
            self.consume_time[tpl] = end_time - start_time
            
            self.cdg_match_result.append(cdg_match_score)
            self.result.append(score)
            self.infos.append(info)
            self.Navigator_log.info(f"[=] Confidence score: {score} | {os.path.basename(self.APK)} <·> {tpl} | Consume Time: {self.consume_time[tpl]:.5f}s")
            
            self.max_score = max(self.max_score, score)
            self.max_cdg_score = max(self.max_cdg_score, cdg_match_score)
            
        return self.get_result()

    def get_result(self):
        res = {}
        if self.max_score >= self.CDG_match_threshold:

            library_level = os.path.basename(self.TPLdir)

            res['Preprocess Time'] = self.preprocess_time
            
            self.Navigator_log.info(f"[+] [Library-level] {library_level}", verbose=True)
            res['Library-level'] = library_level
            res['Version-level'] = {'MatchInfo': {}, 'Version':None}
            for i, tpl in enumerate(self.TPLs):

                res['Version-level']['MatchInfo'][tpl] = {
                    'score': float(self.result[i]),
                    'total': self.infos[i][0],
                    'match': self.infos[i][1],
                    'strong match': self.infos[i][2],
                    "mapping": self.infos[i][3],
                    'total_class_tpl': len(self.preprocessor.TPLData['CDG'][tpl].id2node)
                }
                

            tpl_ver = [i for i in range(len(self.result)) if self.result[i] == self.max_score] 

            if len(tpl_ver) == 1:
                self.Navigator_log.info(f"[+] [Version-level] {self.TPLs[tpl_ver[0]]}", verbose=True)
                res['Version-level']['Version'] = [self.TPLs[tpl_ver[0]]]
                
            elif len(tpl_ver) > 1:
                max_strongmatch = max([self.infos[index][2] for index in tpl_ver])
                indexs = [index for index in tpl_ver if self.infos[index][2] == max_strongmatch]
                if len(indexs) == 1:
                    self.Navigator_log.info(f"[+] [Version-level] {self.TPLs[indexs[0]]}", verbose=True)
                    res['Version-level']['Version'] = [self.TPLs[indexs[0]]]
                    
                elif len(indexs) >= 1:
                    max_match = max([self.infos[index][1] for index in indexs])
                    indexs = [index for index in indexs if self.infos[index][1] == max_match]
                    if len(indexs) == 1:
                        self.Navigator_log.info(f"[+] [Version-level] {self.TPLs[indexs[0]]}", verbose=True)
                        res['Version-level']['Version'] = [self.TPLs[indexs[0]]]
                        
                    elif len(indexs) >= 1:
                        min_total = max([self.result[index] for index in indexs])
                        indexs = [index for index in indexs if self.result[index] == min_total]
                        if len(indexs) == 1:
                            self.Navigator_log.info(f"[+] [Version-level] {self.TPLs[indexs[0]]}", verbose=True)
                            res['Version-level']['Version'] = [self.TPLs[indexs[0]]]
                            
                        elif len(indexs) >= 1:
                            self.Navigator_log.info(f"[+] [Version-level] {', '.join([self.TPLs[index] for index in indexs])}", verbose=True)
                            res['Version-level']['Version'] = [self.TPLs[index] for index in indexs]
            
            if len(res['Version-level']['Version']) > 1 and self.preprocessor.TPLhasRes:
                apkres = [self.preprocessor.APKRes[name]['hash'] for name in self.preprocessor.APKRes]
                res_match = {}
                for tpl in res['Version-level']['Version']:
                    res_match[tpl] = sum(1 for res_name in self.preprocessor.TPLData['Res'][tpl] if self.preprocessor.TPLData['Res'][tpl][res_name]['hash'] in apkres)
                max_match = max(res_match.value())
                res['Version-level']['Version'] = [tpl for tpl in res_match if res_match[tpl] == max_match]
                self.Navigator_log.debug(f"[-] Resource match: {res_match}", verbose=True)
                self.Navigator_log.info(f"[+] [Version-level] {', '.join([tpl for tpl in res_match if res_match[tpl] == max_match])}", verbose=True)
                
            all_sigs = [self.infos[i][4] for i, tpl in enumerate(self.TPLs) if tpl in res['Version-level']['Version']]
            all_ops = [self.infos[i][5] for i, tpl in enumerate(self.TPLs) if tpl in res['Version-level']['Version']]
            all_oprd = [self.infos[i][6] for i, tpl in enumerate(self.TPLs) if tpl in res['Version-level']['Version']]
            all_fldv = [self.infos[i][7] for i, tpl in enumerate(self.TPLs) if tpl in res['Version-level']['Version']]

            if len(res['Version-level']['Version']) > 1 and \
                (max(all_sigs) != min(all_sigs) or max(all_ops) != min(all_ops) or max(all_oprd) != min(all_oprd) or max(all_fldv) != min(all_fldv)):
                tplvers = [tpl for i, tpl in enumerate(self.TPLs) if tpl in res['Version-level']['Version'] and self.infos[i][4] == min(all_sigs)]
                
                if len(tplvers) == 1:
                    self.Navigator_log.info(f"[+] [Version-level] {tplvers[0]}", verbose=True)
                    res['Version-level']['Version'] = tplvers
                else:
                    all_ops = [self.infos[i][5] for i, tpl in enumerate(self.TPLs) if tpl in tplvers]
                    tplvers = [tpl for i, tpl in enumerate(self.TPLs) if tpl in tplvers and self.infos[i][5] == min(all_ops)]
                    
                    if len(tplvers) == 1:
                        self.Navigator_log.info(f"[+] [Version-level] {tplvers}", verbose=True)
                        res['Version-level']['Version'] = tplvers
                    else:
                        all_oprd = [self.infos[i][6] for i, tpl in enumerate(self.TPLs) if tpl in tplvers]
                        tplvers = [tpl for i, tpl in enumerate(self.TPLs) if tpl in tplvers and self.infos[i][6] == min(all_oprd)]
                        
                        if len(tplvers) == 1:
                            self.Navigator_log.info(f"[+] [Version-level] {tplvers}", verbose=True)
                            res['Version-level']['Version'] = tplvers
                        else:
                            all_fldv = [self.infos[i][7] for i, tpl in enumerate(self.TPLs) if tpl in tplvers]
                            tplvers = [tpl for i, tpl in enumerate(self.TPLs) if tpl in tplvers and self.infos[i][7] == min(all_fldv)]
                            self.Navigator_log.info(f"[+] [Version-level] {tplvers}", verbose=True)
                            res['Version-level']['Version'] = tplvers
            

            res['Detection Time'] = self.consume_time
        
        res['Failed Cause'] = self.FAIL_CAUSE
                
        return res
    
        
    def detect(self, matchedpairs, tpl):
        if len(matchedpairs) == 0:
            self.Navigator_log.warning(f"No TPL class Matched.")
            
        self.match_ID = 0
        scores = {}
        blist = set()
        for i, tplnode in enumerate(matchedpairs.keys()):
            scores[tplnode] = {}
            tmp_scores = []
            tmp_fldtypes = []
            TPLnode = self.preprocessor.TPLData['CDG'][tpl].id2node[self.preprocessor.TPLData['CDG'][tpl].desp2id[tplnode]]

            if "interface" in TPLnode.access_flags or \
                "abstract" in TPLnode.access_flags:
                tplnodeTYPE = 1 if "interface" in TPLnode.access_flags else 0

                for apknode in matchedpairs[tplnode]:
                    if apknode in blist:
                        continue
                    
                    APKnode = self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[apknode]]
                    
                    self.Navigator_log.debug(f"[{i}] TPL Interface: {tplnode}, APK Interface: {apknode}")
                    
                    if "interface" not in APKnode.access_flags and "abstract" not in APKnode.access_flags:
                        continue

                    apknodeTYPE = 1 if "interface" in TPLnode.access_flags else 0
                    if tplnodeTYPE != apknodeTYPE:
                        continue

                    if tplnode == apknode:
                        scores[tplnode][apknode] = (1.0, set())
                        blist.add(apknode)
                        self.Navigator_log.debug(f"[·] Signature match: {scores[tplnode][apknode]}")
                        break
                    
                    cleanSigAPK = [self.signatureClean(item) for item in APKnode.members]
                    cleanSigTPL = [self.signatureClean(item) for item in TPLnode.members]
                    if apknodeTYPE == 0 and tplnodeTYPE == 0:
                        tplcodes = Counter(op for key in TPLnode.methods_infos['methodOpcodes'] for op in TPLnode.methods_infos['methodOpcodes'][key])
                        apkcodes = Counter(op for key in APKnode.methods_infos['methodOpcodes'] for op in APKnode.methods_infos['methodOpcodes'][key])
                        if len(cleanSigTPL):
                            if len(tplcodes):
                                scores[tplnode][apknode] = ((sum((Counter(cleanSigAPK)&Counter(cleanSigTPL)).values())/len(cleanSigTPL) + sum((tplcodes&apkcodes).values())/sum(tplcodes.values()))/2, set())
                            else:
                                scores[tplnode][apknode] = (sum((Counter(cleanSigAPK)&Counter(cleanSigTPL)).values())/len(cleanSigTPL), set())
                                self.Navigator_log.debug(f"[·] Signature match: {scores[tplnode][apknode]}")

                        else:
                            if (len(cleanSigAPK) == 1 and 'static' in cleanSigAPK[0]) or len(cleanSigAPK) == 0:
                                scores[tplnode][apknode] = (0.8, set())
                                self.Navigator_log.debug(f"[·] Signature match: {scores[tplnode][apknode]}")
                    else:
                        if Counter(cleanSigAPK) == Counter(cleanSigTPL):
                            if len(cleanSigTPL):
                                scores[tplnode][apknode] = (sum((Counter(cleanSigAPK)&Counter(cleanSigTPL)).values())/len(cleanSigTPL), set())
                                self.Navigator_log.debug(f"[·] Signature match: {scores[tplnode][apknode]}")

                            else:
                                scores[tplnode][apknode] = (0.8, set())
                                self.Navigator_log.debug(f"[·] Signature match: {scores[tplnode][apknode]}")

                continue

            tmpapknodes = []

            if len(TPLnode.members) == 0:
                for apknode in matchedpairs[tplnode]:
                    self.Navigator_log.debug(f"[{i}] TPL Class: {tplnode}, APK Class: {apknode}")
                    if len(self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[apknode]].members) == 0 or\
                        (len(self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[apknode]].members) == 1 and "<clinit>" in self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[apknode]].members[0]):
                        tmpapknodes.append(apknode)
                        if apknode == tplnode:
                            scores[tplnode][apknode] = (1.0, set())
                            self.Navigator_log.debug(f"[·] Class match: {scores[tplnode][apknode]}")
                            blist.add(apknode)
                            break
                if len(scores[tplnode]) == 0:
                    for item in tmpapknodes:
                        scores[tplnode][item] = (1.0, set())
                        self.Navigator_log.debug(f"[·] Class match: {scores[tplnode][item]}")
                continue
                    
            for apknode in matchedpairs[tplnode]:
                if apknode in blist or apknode not in self.preprocessor.APKData.desp2id:
                    continue
                
                self.Navigator_log.debug("")
                self.Navigator_log.debug(f"[{i}] TPL Class: {tplnode}, APK Class: {apknode}")
                
                APKnode = self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[apknode]]
                
                if "interface" in APKnode.access_flags or "abstract" in APKnode.access_flags:
                    continue

                
                executor = Executor(i, APKnode, TPLnode, {'apk':self.preprocessor.APKData, 'tpl':self.preprocessor.TPLData['CDG'][tpl]}, logger=self.Executor_log)
                sc_score, fldtypes = executor()

                tmp_scores.append(sc_score)
                tmp_fldtypes.append(fldtypes)
                tmpapknodes.append(apknode)
                if sc_score >= self.high_confidence:
                    blist.add(apknode)
                    break
                    
            if len(tmp_scores):
                max_score = max(tmp_scores)
                for i in range(len(tmp_scores)):
                    if tmp_scores[i] == max_score:
                        scores[tplnode][tmpapknodes[i]] = (max_score, tmp_fldtypes[i])
            
        return scores
    
    
    def signatureClean(self, signature):
        access_flags = signature[signature.rfind("|")+1:]
        access_flags = access_flags.split(" ")
        if "public" in access_flags:
            access_flags.remove("public")
        if "final" in access_flags:
            access_flags.remove("final")
        if "protected" in access_flags:
            access_flags.remove("protected")
        if "private" in access_flags:
            access_flags.remove("private")
        return signature[:signature.rfind("|")] + '|' + " ".join(access_flags)
        
    def enhance_confidence(self, unique_strongmatch_nodes, match_scores, tplAttrGraph, apkAttrGraph):
        import copy
        for smn_tpl in unique_strongmatch_nodes:
            smn_apk = unique_strongmatch_nodes[smn_tpl]
            for tplnode in match_scores:
                if tplnode in unique_strongmatch_nodes:
                    continue
                FIND = False
                in_edge_types = []
                if smn_tpl in [item[1] for item in tplAttrGraph[tplnode]]:
                    for (node, edge) in tplAttrGraph[tplnode]:
                        if node == smn_tpl:
                            in_edge_types.append(edge)
                    if len(in_edge_types):
                        for apknode in match_scores[tplnode]:
                            tmp_edge_types = copy.deepcopy(in_edge_types)
                            for (node, edge) in apkAttrGraph[apknode]:
                                if node == smn_apk:
                                    tmp_edge_types.remove(edge)
                            if len(tmp_edge_types) == 0:
                                match_scores[tplnode][apknode][0] = min(1.0, match_scores[tplnode][apknode][0]+self.high_confidence/2)

                out_edge_types = []
                if tplnode in [item[1] for item in tplAttrGraph[smn_tpl]]:
                    for (node, edge) in tplAttrGraph[smn_tpl]:
                        if node == tplnode:
                            out_edge_types.append(edge)
                    if len(out_edge_types):
                        for apknode in match_scores[tplnode]:
                            tmp_edge_types = copy.deepcopy(out_edge_types)
                            for (node, edge) in apkAttrGraph[smn_apk]:
                                if node == apknode:
                                    tmp_edge_types.remove(edge)
                            if len(tmp_edge_types) == 0:
                                match_scores[tplnode][apknode][0] = min(1.0, match_scores[tplnode][apknode][0]+self.high_confidence/2)

        return match_scores


    def isMatch(self, match_scores, tplgraph, apkgraph, tplCDG, tplAttrGraph, apkAttrGraph, tpl):
        unique_strongmatch_nodes = {}
        for tplnode in match_scores:
            if tplnode[1:-1].split('/')[-1] == "BuildConfig":
                continue
            if len(match_scores[tplnode]) == 0:
                continue
            max_score = max([score for (score, _) in match_scores[tplnode].values()])
            if max_score >= self.high_confidence and len(match_scores[tplnode]) == 1:
                unique_strongmatch_nodes[tplnode] = list(match_scores[tplnode].keys())[0]
        match_scores = self.enhance_confidence(unique_strongmatch_nodes, match_scores, tplAttrGraph, apkAttrGraph)

        matches = 0
        definite_matches = 0
        total = 0
        missed = set()
        mapping = {}
        new_mapping = {'strong':{}, 'weak':{}}
        all_tpls = set()
        all_apks = set()
        itfcs = set()
        
        for key in match_scores:
            if key[1:-1].split('/')[-1] != "BuildConfig":
                all_tpls.add(key)
            for apk in match_scores[key]:
                if match_scores[key][apk][0] >= self.node_match_threshold and apk[1:-1].split('/')[-1] != "BuildConfig":
                    all_apks.add(apk)
                
        apk_all_match_nodes = []
        tpl_all_match_nodes = []
        apk_strongmatch_nodes = []
        tpl_strongmatch_nodes = []
        tpl_match_opcodes = 0
        total_tpl_match_opcodes = 0
        for node in tplCDG.id2node.values():
            if "abstract" in node.access_flags or "interface" in node.access_flags:
                total_tpl_match_opcodes += len(node.methods_infos['methodSignatures'])*self.mtd_weight
            else:
                for opcodes in node.methods_infos['methodOpcodes'].values():
                    total_tpl_match_opcodes += len(opcodes)

        signature_sub = 0
        opcode_sub = 0
        mtdOprd_sub = 0
        fldValue_sub = 0
        used_field_types = set()
        for tplnode in match_scores:
            if tplnode[1:-1].split('/')[-1] == "BuildConfig":
                continue

            tplCDGnode = tplCDG.id2node[tplCDG.desp2id[tplnode]]
            if "interface" in tplCDGnode.access_flags:
                itfcs.add(tplnode)

            if len(match_scores[tplnode]) == 0:
                missed.add(tplnode)
                continue
            total += 1

            mtdinfo = tplCDGnode.methods_infos['methodOpcodes']
            tplfldValue = Counter([item for key in tplCDGnode.fld_init_value for item in tplCDGnode.fld_init_value[key]])
            max_score = max([score for (score, _) in match_scores[tplnode].values()])
            if max_score >= self.high_confidence:
                definite_matches += 1
                mapping[tplnode] = []
                new_mapping['strong'][tplnode] = []
                for i, (key, (score, fldtypes)) in enumerate(match_scores[tplnode].items()):
                    if score == max_score:
                        mapping[tplnode].append(key)
                        new_mapping['strong'][tplnode].append(key)
                        used_field_types |= fldtypes

                apk_strongmatch_nodes += mapping[tplnode]
                apk_all_match_nodes += mapping[tplnode]
                tpl_strongmatch_nodes.append(tplnode)
                tpl_all_match_nodes.append(tplnode)
                if "interface" in tplCDGnode.access_flags or "abstract" in tplCDGnode.access_flags:
                    for mtd in mtdinfo:
                        if "abstract" in mtd:
                            tpl_match_opcodes += self.mtd_weight
                        else:
                            tpl_match_opcodes += len(mtdinfo[mtd])
                else:
                    tpl_match_opcodes += sum([len(mtdinfo[mtd]) for mtd in mtdinfo])

            elif max_score >= self.node_match_threshold:
                
                matches += 1
                mapping[tplnode] = [key for i, (key, (score, _)) in enumerate(match_scores[tplnode].items()) if score == max_score]
                new_mapping['weak'][tplnode] = [key for i, (key, (score, _)) in enumerate(match_scores[tplnode].items()) if score == max_score]
                apk_all_match_nodes += mapping[tplnode]
                tpl_all_match_nodes.append(tplnode)
                if "interface" in tplCDGnode.access_flags or "abstract" in tplCDGnode.access_flags:
                    for mtd in mtdinfo:
                        if "abstract" in mtd:
                            tpl_match_opcodes += self.mtd_weight
                        else:
                            tpl_match_opcodes += len(mtdinfo[mtd])
                else:
                    tpl_match_opcodes += sum([len(mtdinfo[mtd]) for mtd in mtdinfo])

            else:
                missed.add(tplnode)
                continue

            if len(mapping[tplnode]) == 1:
                apkCDGnode = self.preprocessor.APKData.id2node[self.preprocessor.APKData.desp2id[mapping[tplnode][0]]]
                if not any("<clinit>" in memb for memb in tplCDGnode.members) and any("<clinit>" in memb for memb in apkCDGnode.members):
                    signature_sub += len(Counter([self.signatureClean(memb) for memb in apkCDGnode.members if "<clinit>" not in memb]) - Counter([self.signatureClean(memb) for memb in tplCDGnode.members if "<clinit>" not in memb])) + len(Counter([self.signatureClean(memb) for memb in tplCDGnode.members if "<clinit>" not in memb]) - Counter([self.signatureClean(memb) for memb in apkCDGnode.members if "<clinit>" not in memb]))
                    opcode_sub += len(Counter([op for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for op in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([op for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for op in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]])) + \
                                len(Counter([op for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for op in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([op for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for op in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]))
                    mtdOprd_sub += len(Counter([const for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for const in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([const for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for const in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]])) + \
                                len(Counter([const for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for const in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([const for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] if "<clinit>" not in mtdsig for const in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]))
                else:
                    signature_sub += len(Counter([self.signatureClean(memb) for memb in apkCDGnode.members]) - Counter([self.signatureClean(memb) for memb in tplCDGnode.members])) + len(Counter([self.signatureClean(memb) for memb in tplCDGnode.members]) - Counter([self.signatureClean(memb) for memb in apkCDGnode.members]))
                    opcode_sub += len(Counter([op for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] for op in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([op for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] for op in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]])) + \
                                len(Counter([op for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] for op in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([op for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] for op in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]))
                    mtdOprd_sub += len(Counter([const for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] for const in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([const for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] for const in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]])) + \
                                len(Counter([const for mtdsig in tplCDGnode.methods_infos['methodOpcodes'] for const in tplCDGnode.methods_infos['methodOpcodes'][mtdsig]]) - Counter([const for mtdsig in apkCDGnode.methods_infos['methodOpcodes'] for const in apkCDGnode.methods_infos['methodOpcodes'][mtdsig]]))
                fldValue_sub += len(Counter([item for fldsig in apkCDGnode.fld_init_value for item in apkCDGnode.fld_init_value[fldsig]]) - tplfldValue) + \
                            len(tplfldValue - Counter([item for fldsig in apkCDGnode.fld_init_value for item in apkCDGnode.fld_init_value[fldsig]]))

        FAIL_RET = (.0, .0, (0, 0, 0, {}, 0, 0, 0, 0))
        self.Navigator_log.debug(f"[=] Total: {total}, match: {matches}, strong match: {definite_matches}")
        if total == 0 or (definite_matches+matches == 0):
            self.FAIL_CAUSE[tpl] = 0
            return FAIL_RET
        
        pureItfcClass = sum([1 if 'interface' in tplCDG.id2node[id].access_flags or 'abstract' in tplCDG.id2node[id].access_flags else 0 for id in tplCDG.id2node]) == len(tplCDG.id2node)
        detectItfcClass = sum([1 if 'interface' in tplCDG.id2node[tplCDG.desp2id[clz]].access_flags or 'abstract' in tplCDG.id2node[tplCDG.desp2id[clz]].access_flags else 0 for clz in mapping]) == len(mapping)

        if not pureItfcClass:
            if tpl_match_opcodes/total_tpl_match_opcodes < self.CDG_match_threshold:

                self.FAIL_CAUSE[tpl] = 1
                return FAIL_RET
            
            def isExtClass(clzname):
                while clzname[0] == '[':
                    clzname = clzname[1:]
                for item in BLIST:
                    if clzname.startswith(item):
                        return True
                if clzname in ['B', 'C', 'D', 'F', 'I', 'J', 'S', 'Z', 'V']:
                    return True
                return False
            
            used_field_types = set(fldt for fldt in used_field_types if not isExtClass(fldt) and fldt in tplCDG.desp2id)
            if len(used_field_types - set(mapping.keys()))/len(mapping) > self.node_match_threshold:
                self.FAIL_CAUSE[tpl] = 2
                return FAIL_RET

            if len(set(apk_strongmatch_nodes)) < len(set(tpl_strongmatch_nodes)):
                self.FAIL_CAUSE[tpl] = 3
                return FAIL_RET
        
            if detectItfcClass:
                self.FAIL_CAUSE[tpl] = 4
                return FAIL_RET

            tplsrcnodes, tplsinknodes, tplallnodes = self.find_src_sink(tplgraph, mapping)
            apksrcnodes = set()
            apksinknodes = set()
            apkallnodes = set()
            for item in tplsrcnodes:
                apksrcnodes |= set(mapping[item])
            for item in tplsinknodes:
                apksinknodes |= set(mapping[item])
            for item in mapping.values():
                apkallnodes |= set(item)

            if len(tplsinknodes) == 0:
                _, simplesink, _ = self.find_Simplesrc_sink(tplAttrGraph, mapping)

                if len(simplesink) == 0:
                    self.FAIL_CAUSE[tpl] = 5
                    return FAIL_RET

            if len(tplsinknodes) == len(tplallnodes):
                
                extra_deps = []
                extra_clz = []
                for n in tplsinknodes:
                    for edge in tplAttrGraph[n]:
                        if self.getClass(edge[1]) not in tplAttrGraph and (not isExtClass(edge[1])) and n not in extra_deps:
                            extra_clz.append(edge[1])
                            extra_deps.append(n)
                
                apk_out_degree_nodes = set()
                for item in apkgraph:
                    if len(apkgraph[item]) and any(not isExtClass(an) for an in apkgraph[item] if self.getClass(an) != item):
                        apk_out_degree_nodes.add(item)
                if len(extra_deps):
                    for n in extra_deps:
                        if len(set(mapping[n]) & apk_out_degree_nodes) == 0:
                            self.FAIL_CAUSE[tpl] = 6
                            return FAIL_RET
                else:
                    apk_without_out_degree_nodes = set(apkallnodes)-apk_out_degree_nodes
                    for n in tplsinknodes:
                        if len(set(mapping[n]) & apk_without_out_degree_nodes) == 0:
                            self.FAIL_CAUSE[tpl] = 7
                            return FAIL_RET
            
            elif len(tplsinknodes) and len(tplsrcnodes-tplsinknodes):
                if (not self.does_path_exist(tplgraph, tplsrcnodes-tplsinknodes, tplsinknodes, tplallnodes)):
                    self.FAIL_CAUSE[tpl] = 8
                    return FAIL_RET
                    
                else:
                    if not self.does_path_exist(apkgraph, apksrcnodes-apksinknodes, apksinknodes, apkallnodes):
                        self.FAIL_CAUSE[tpl] = 9
                        return FAIL_RET
                    
            if len(itfcs) and len(itfcs-missed)/len(itfcs) < self.CDG_match_threshold:
                self.FAIL_CAUSE[tpl] = 10
                return FAIL_RET

        else:
            if definite_matches+matches != len(tplCDG.id2node) or len(set(tpl_all_match_nodes)) > len(set(apk_all_match_nodes)):
                self.FAIL_CAUSE[tpl] = 11
                return FAIL_RET

        precise_match = {}
        for tplmtd in mapping:
            if len(mapping[tplmtd]) == 1:
                precise_match[tplmtd] = mapping[tplmtd][0]
        
        if len(precise_match):
            for tplmtd in mapping:
                if tplmtd in precise_match:
                    continue
                tpltgts = self.has_connection(tplmtd, set(precise_match.keys()), tplAttrGraph)
                if len(tpltgts):
                    for apkmtd in mapping[tplmtd]:
                        for (tpltgt, etype) in tpltgts.items():
                            if len(self.has_connection(apkmtd, {precise_match[tpltgt]}, apkAttrGraph, etype)):
                                precise_match[tplmtd] = apkmtd
                                break
            
            mapping.update(precise_match)

        return len(all_apks)/len(all_tpls), (Decimal(definite_matches) * Decimal(str(self.dm_weight)) + Decimal(matches))/Decimal(total), (total, matches, definite_matches, mapping, signature_sub, opcode_sub, mtdOprd_sub, fldValue_sub)
        
        
    def has_connection(self, srcnode, matched_nodes, attrgraph, _etype=None):
        tgtnodes = {}
        for src in matched_nodes:
            if src in attrgraph:
                for (etype, tgt) in attrgraph[src]:
                    if tgt == srcnode:
                        if _etype:
                            if _etype[0] == etype and _etype[1] == "src":
                                tgtnodes[src] = [etype, "src"]
                        else:
                            tgtnodes[src] = [etype, "src"]
        if srcnode in attrgraph:
            for (etype, tgt) in attrgraph[src]:
                if tgt in matched_nodes:
                    if _etype:
                        if _etype[0] == etype and _etype[1] == "tgt":
                            tgtnodes[tgt] = [etype, "tgt"]
                    else:
                        tgtnodes[tgt] = [etype, "tgt"]
        return tgtnodes

    def getClass(self, clzname):
        while clzname[0] == '[':
            clzname = clzname[1:]
        return clzname

    def find_Simplesrc_sink(self, Attrgraph, mapping):
        tplsrcNodes = set()
        tplsinknodes = set()
        tplallnode = set()
        for node in Attrgraph:
            if node in mapping:
                tplallnode.add(node)
                isSink = True
                for edgetype, neighbor in Attrgraph[node]:
                    if self.getClass(neighbor) in Attrgraph and self.getClass(neighbor) != node and edgetype in ['extends', 'implements']:
                        isSink = False
                if isSink:
                    tplsinknodes.add(node)

                if len(Attrgraph[node]):
                    for edgetype, _node in Attrgraph[node]:
                        if self.getClass(_node) in mapping and self.getClass(_node) in Attrgraph:
                            tplsrcNodes.add(self.getClass(_node))

        tplsrcNodes = tplallnode - tplsrcNodes
                    
        return tplsrcNodes, tplsinknodes, tplallnode

    def find_src_sink(self, graph, mapping):
        tplsrcNodes = set()
        tplsinknodes = set()
        tplallnode = set()
        for node in graph:
            if node in mapping:
                tplallnode.add(node)
                isSink = True
                for neighbor in graph[node]:
                    if self.getClass(neighbor) in graph and self.getClass(neighbor) != node:
                        isSink = False
                if isSink:
                    tplsinknodes.add(node)

                if len(graph[node]):
                    for _node in graph[node]:
                        if self.getClass(_node) in mapping:
                            tplsrcNodes.add(self.getClass(_node))

        tplsrcNodes = tplallnode - tplsrcNodes
                    
        return tplsrcNodes, tplsinknodes, tplallnode
    
    def check_same_path(self, tplAttrGraph, apkAttrGraph, tplparent, mapping, tplsinknodes):
        apkparents = mapping[tplparent]
        while tplparent in tplAttrGraph and tplparent not in tplsinknodes and len(tplAttrGraph[tplparent]):
            print("check_same_path")
            tplchildinfo = None
            edgetypes = [child[0] for child in tplAttrGraph[tplparent]]
            if 'extends' in edgetypes:
                tplchildinfo = tplAttrGraph[tplparent][edgetypes.index('extends')]
            elif 'reference' in edgetypes:
                tplchildinfo = tplAttrGraph[tplparent][edgetypes.index('reference')]
            else:
                break
            tpledgetype, tplchild = tplchildinfo[0], self.getClass(tplchildinfo[1])
            if tplchild not in tplAttrGraph:
                break
            
            candidates = set()
            for apkparent in apkparents:
                for (apkedgetype, apkchild) in apkAttrGraph[apkparent]:
                    if apkedgetype == tpledgetype and \
                        tplchild in mapping and \
                        self.getClass(apkchild) in mapping[tplchild]:
                        candidates.add(self.getClass(apkchild))
                        break
            
            if len(candidates) == 0:
                return False
            else:
                tplparent = tplchild
                apkparents = candidates
            
        return True
        

    def does_path_exist(self, graph, start_nodes, end_nodes, nodes_set):
        fail_node = set()
        def dfs(node, visited, fail_node):
            # If the node is an end node, return True if path included all nodes in S
            if node in end_nodes:
                if not nodes_set.issuperset(visited):
                    fail_node |= visited-nodes_set
                return nodes_set.issuperset(visited)
            
            for neighbor in graph.get(node, []):
                # Continue the search if this path hasn't visited this neighbor
                if self.getClass(neighbor) not in visited and node != self.getClass(neighbor):
                    # Mark the node as visited
                    visited.add(self.getClass(neighbor))
                    # print(node, self.getClass(neighbor))
                    if dfs(self.getClass(neighbor), visited, fail_node):
                        return True
            return False

        for start_node in start_nodes:
            if start_node not in nodes_set:
                continue
            
            if dfs(start_node, {start_node}, fail_node):
                return True

        return False
    